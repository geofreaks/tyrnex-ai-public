# Basic local rogue-device/DHCP visibility probe for TYRNEX-AI.
# Safe behavior: starts one Docker container, records its own IP/gateway status, and does not scan the LAN.
param(
  [Parameter(Position = 0)]
  [ValidateSet("up", "down", "status", "logs")]
  [string]$Command = "status",

  [ValidateSet("bridge", "host")]
  [string]$Mode = "bridge",

  [int]$IntervalSeconds = 5
)

$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $PSScriptRoot
$Image = "tyrnex-ai-rogue-dhcp-probe:local"
$Container = "tyrnex-ai-rogue-dhcp-probe"
$DockerfileDir = Join-Path $Root "lab\rogue-dhcp-probe"
$StatusDir = Join-Path $Root "data\rogue-dhcp-probe"

function Test-DockerReady {
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { return $false }
  try {
    docker info --format "{{.ServerVersion}}" 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
  } catch {
    return $false
  }
}

function Read-ProbeStatus([bool]$DockerReady = $true) {
  $statusPath = Join-Path $StatusDir "status.json"
  if (Test-Path $statusPath) {
    try { return Get-Content $statusPath -Raw | ConvertFrom-Json } catch {}
  }
  if (-not $DockerReady) { return $null }
  try {
    $raw = docker exec $Container cat /status/status.json 2>$null
    if ($LASTEXITCODE -eq 0 -and $raw) { return ($raw | ConvertFrom-Json) }
  } catch {}
  return $null
}

function Show-ProbeStatus([bool]$DockerReady = $true) {
  $containerInfo = $null
  if ($DockerReady) {
    try {
      $containerInfo = docker inspect $Container 2>$null | ConvertFrom-Json
    } catch {}
  }
  $running = $false
  if ($containerInfo) {
    $running = [bool]$containerInfo[0].State.Running
  }
  $status = Read-ProbeStatus -DockerReady $DockerReady
  Write-Host ""
  Write-Host "TYRNEX-AI LAN DHCP Probe" -ForegroundColor Cyan
  $containerState = if ($running) { "running" } elseif ($DockerReady) { "not running" } else { "docker not ready" }
  Write-Host ("Container: {0}" -f $containerState)
  if ($status) {
    $state = if ($status.connected) { "connected" } else { "not connected" }
    $gw = if ($status.gateway_reachable) { "gateway reachable" } else { "gateway not reachable" }
    $visible = if ($status.lan_visible) { "LAN-visible mode" } else { "Docker NAT/bridge mode" }
    $cache = if ($running) { "" } else { " (cached last status)" }
    $statusColor = if ($running -and $status.connected) { "Green" } elseif ($status.connected) { "Yellow" } else { "Yellow" }
    Write-Host ("Status:    {0}; {1}; {2}{3}" -f $state, $gw, $visible, $cache) -ForegroundColor $statusColor
    Write-Host ("IP/CIDR:   {0}" -f $status.cidr)
    Write-Host ("Gateway:   {0}" -f $status.gateway)
    Write-Host ("MAC:       {0}" -f $status.mac)
    Write-Host ("Updated:   {0}" -f $status.timestamp)
    Write-Host ("Note:      {0}" -f $status.note)
  } else {
    Write-Host "Status:    no status file yet" -ForegroundColor Yellow
  }
  Write-Host ""
  Write-Host "Windows Docker Desktop usually uses NAT/bridge networking, so this is a local visibility smoke test." -ForegroundColor DarkYellow
  Write-Host "For a true LAN DHCP rogue-device test, run from native Linux/macvlan/ipvlan or another lab VM/device." -ForegroundColor DarkYellow
}

New-Item -ItemType Directory -Force -Path $StatusDir | Out-Null
$DockerReady = Test-DockerReady

if (-not $DockerReady -and $Command -eq "status") {
  Show-ProbeStatus -DockerReady $false
  exit 0
}

if (-not $DockerReady -and $Command -eq "down") {
  Remove-Item -LiteralPath (Join-Path $StatusDir "status.json") -Force -ErrorAction SilentlyContinue
  Write-Host "Docker is not ready; no running probe container can be stopped from here." -ForegroundColor Yellow
  Write-Host "Cleared cached LAN DHCP probe status." -ForegroundColor Green
  exit 0
}

if (-not $DockerReady) {
  Write-Host "Docker is not ready. Start Docker Desktop, then rerun this probe." -ForegroundColor Red
  exit 1
}

switch ($Command) {
  "up" {
    Write-Host "Building LAN DHCP probe image..." -ForegroundColor Cyan
    docker build -t $Image $DockerfileDir
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    docker rm -f $Container 2>$null | Out-Null
    $runArgs = @(
      "run", "-d",
      "--name", $Container,
      "--label", "tyrnex-ai.role=rogue-dhcp-probe",
      "-e", "TYRNEX_PROBE_MODE=$Mode",
      "-e", "PROBE_INTERVAL_SECONDS=$IntervalSeconds",
      "-v", "${StatusDir}:/status"
    )
    if ($Mode -eq "host") {
      $runArgs += @("--network", "host")
    }
    $runArgs += $Image
    docker @runArgs | Out-Host
    Start-Sleep -Seconds 2
    Show-ProbeStatus
  }
  "down" {
    docker rm -f $Container 2>$null | Out-Null
    Remove-Item -LiteralPath (Join-Path $StatusDir "status.json") -Force -ErrorAction SilentlyContinue
    Write-Host "LAN DHCP probe stopped." -ForegroundColor Green
  }
  "status" {
    Show-ProbeStatus
  }
  "logs" {
    $exists = $false
    try {
      docker inspect $Container 2>$null | Out-Null
      $exists = ($LASTEXITCODE -eq 0)
    } catch {}
    if (-not $exists) {
      Write-Host "LAN DHCP probe container is not present. Start it first with: rogue-dhcp-probe.ps1 up" -ForegroundColor Yellow
      exit 0
    }
    docker logs --tail 80 $Container
  }
}
