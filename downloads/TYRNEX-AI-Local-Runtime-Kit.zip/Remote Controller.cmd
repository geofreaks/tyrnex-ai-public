@echo off
setlocal
cd /d "%~dp0"
if not exist "tyrnex_ai" if exist "tyrnex-ai-app\tyrnex_ai" cd /d "%~dp0tyrnex-ai-app"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -m tyrnex_ai.remote serve
) else (
  python -m tyrnex_ai.remote serve
)
if errorlevel 1 echo Controller did not start. Run first-run setup and see docs\remote-agent\OPERATIONS.md.
pause
