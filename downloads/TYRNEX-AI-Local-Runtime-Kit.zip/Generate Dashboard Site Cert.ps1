param(
  [string]$HostName = "0.0.0.0",
  [string]$AdvertisedHost = "",
  [string]$Db = ".\data\TYRNEX-AI.db",
  [switch]$TrustCurrentUser,
  [switch]$NoTrustPrompt
)

$ErrorActionPreference = "Stop"

function Resolve-Root {
  $here = Split-Path -Parent $MyInvocation.ScriptName
  if (Test-Path -LiteralPath (Join-Path $here "tyrnex_ai")) { return $here }
  $nested = Join-Path $here "tyrnex-ai-app"
  if (Test-Path -LiteralPath (Join-Path $nested "tyrnex_ai")) { return $nested }
  return $here
}

$root = Resolve-Root
Set-Location $root
$python = if (Test-Path -LiteralPath ".\.venv\Scripts\python.exe") { ".\.venv\Scripts\python.exe" } else { "python" }

function Test-WindowsHost {
  return [string]::Equals($env:OS, "Windows_NT", [StringComparison]::OrdinalIgnoreCase)
}

function Install-DashboardCaForCurrentUser {
  param([string]$CaPath)
  if (-not (Test-WindowsHost)) {
    Write-Host "Automatic trust install is only supported on Windows." -ForegroundColor Yellow
    return
  }
  if (-not (Test-Path -LiteralPath $CaPath)) {
    throw "Dashboard CA certificate was not found: $CaPath"
  }
  $certutil = Join-Path $env:SystemRoot "System32\certutil.exe"
  if (-not (Test-Path -LiteralPath $certutil)) {
    $certutil = "certutil.exe"
  }
  Write-Host ""
  Write-Host "Installing TYRNEX dashboard CA into Current User\Trusted Root Certification Authorities..."
  Write-Host "This trusts only certificates issued by this local TYRNEX dashboard CA for this Windows user."
  & $certutil -user -addstore Root $CaPath | Out-Host
  if ($LASTEXITCODE -ne 0) {
    throw "Windows certificate trust install failed."
  }
  Write-Host "Dashboard CA trusted for the current Windows user." -ForegroundColor Green
}

$code = @'
import argparse
from pathlib import Path
from tyrnex_ai.dashboard_tls import dashboard_preferred_host_path, ensure_dashboard_tls
from tyrnex_ai.networking import advertised_host

p = argparse.ArgumentParser()
p.add_argument("--host", default="0.0.0.0")
p.add_argument("--advertised", default="")
p.add_argument("--db", default="./data/TYRNEX-AI.db")
args = p.parse_args()
display = args.advertised.strip() or advertised_host(args.host)
tls = ensure_dashboard_tls(Path(args.db), args.host, display)
preferred = dashboard_preferred_host_path(Path(args.db))
preferred.parent.mkdir(parents=True, exist_ok=True)
preferred.write_text(display, encoding="utf-8")
print("TYRNEX-AI dashboard/site HTTPS certificate ready")
print(f"Dashboard URL: https://{display}:8765/")
print(f"CA certificate: {tls.ca}")
print(f"Site certificate: {tls.cert}")
print(f"Site private key: {tls.key}")
print(f"Dashboard startup binding: {preferred}")
print(f"Certificate SHA-256: {tls.fingerprint}")
print("")
print("Trust the CA certificate on machines that should open this local TYRNEX dashboard without a browser warning.")
'@

$tmp = Join-Path $env:TEMP ("tyrnex-generate-site-cert-" + [guid]::NewGuid().ToString("N") + ".py")
$code | Set-Content -LiteralPath $tmp -Encoding UTF8
try {
  $args = @($tmp, "--host", $HostName, "--db", $Db)
  if (-not [string]::IsNullOrWhiteSpace($AdvertisedHost)) {
    $args += @("--advertised", $AdvertisedHost)
  }
  $output = & $python @args
  if ($LASTEXITCODE -ne 0) { throw "Certificate generation failed." }
  $output | ForEach-Object { Write-Host $_ }
} finally {
  Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
}

$caPath = Join-Path $root "data\dashboard-tls\dashboard-ca.pem"
if ($TrustCurrentUser) {
  Install-DashboardCaForCurrentUser -CaPath $caPath
} elseif (-not $NoTrustPrompt -and (Test-WindowsHost)) {
  Write-Host ""
  Write-Host "Browser trust note:" -ForegroundColor Cyan
  Write-Host "The dashboard is already configured to use the generated HTTPS certificate."
  Write-Host "To remove browser warnings on this PC, Windows must trust the local TYRNEX dashboard CA."
  $answer = Read-Host "Trust the TYRNEX dashboard CA for the current Windows user now? [Y/n]"
  if ([string]::IsNullOrWhiteSpace($answer) -or $answer.Trim().ToLowerInvariant().StartsWith("y")) {
    Install-DashboardCaForCurrentUser -CaPath $caPath
  } else {
    Write-Host "Skipped Windows trust install. You can rerun with -TrustCurrentUser later."
  }
}
