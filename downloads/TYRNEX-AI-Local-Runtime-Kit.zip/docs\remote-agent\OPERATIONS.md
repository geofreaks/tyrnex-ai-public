# Remote Devices: Local Portable Pilot

This is an opt-in implementation, not a production qualification or a NodeZero
equivalent. Existing local capture and PentestGPT workflows are unchanged.

See [current endpoint capabilities and remaining integrations](CAPABILITIES.md)
for the new, separately opted-in HTTP/TLS validation task and exact remote limits.

## What Is Implemented

- Native Windows x64 agent; no Python or full tool bundle on endpoints.
- Outbound HTTPS with a private controller CA and approved per-device certificates.
- Administrator-generated, 30-minute enrollment packages bound to one device
  identity and case generation. Manual CSR approval remains available.
- Local-controller dashboard access and authenticated shared HTTPS access with
  named viewer/operator/admin roles. Standalone console accepts bearer tokens.
- Durable SQLite jobs, case-instance isolation, serialized pilot collection,
  cancellation acknowledgements, leases, resumable hashed uploads and audit rows.
- Inventory, shared-evaluator posture, last-24-hour event logs and focused disk
  triage (logs plus posture). Focused disk is NOT a full forensic disk image or KAPE.
- Foreground memory acquisition with locally pinned WinPmem, local opt-in,
  administrator rights and an explicit storage budget. No automatic elevation,
  AV/EDR bypass, exclusions, remote shell or self-propagation. Installer downloads
  use the package CA and expected SHA-256, never unverified TLS or HTTP fallback.
- Separately opted-in, scope-bound IPv4 TCP runner with source-interface selection,
  allow/deny expectations, exclusions, rate/time budgets and same-plan retesting.
- Automatic renewal of enrolled device certificates during their final seven days,
  using the existing mTLS identity and key; device revocation covers renewed certs.
- Central Host Exam/Volatility and report pipeline for evidence, with coverage
  warnings and original SHA-256 provenance. Disk and memory from the same enrolled
  device feed the same case/host examination. Each collection also has its report.
- Protected compiled-Python kit and private bootstrap builders include the native
  agent and this guide. Device keys, CA keys, tokens, state and evidence are never
  included in redistribution packages.

## Initial Controller Setup

### Dashboard Setup and Switch

Open the main dashboard on the controller PC using its HTTPS LAN address, such as
`https://10.10.1.44:8765`, or loopback at `http://127.0.0.1:8765` when you only
need this PC. LAN-bound dashboard launches create a local dashboard certificate
under `data\dashboard-tls\` and print the certificate SHA-256 at startup. Select
**Remote devices** in the sidebar. This opens the endpoint workspace inside the
main dashboard. **Controller settings** opens setup and the listener switch. A
separate console window is not required.

For a new identity the address defaults to the freshly detected LAN IPv4 address,
preferring the physical gateway-connected adapter. Manual address and listener
selections survive status refreshes. If no usable address is found, enter one
manually; an existing certificate identity is never silently rewritten. A detected
LAN address selects network listener mode, but LAN approval is still unchecked and
no listener starts automatically. For a local-only test, enter `127.0.0.1` and
select **This PC only** together.

1. For first-time setup, enter the certificate hostname/IP and HTTPS port. For real
   remote endpoints, choose the controller's actual reachable hostname/IP, not
   `127.0.0.1`. Approve setup and select **Create controller**. The dashboard
   generates a local controller unlock key automatically under the protected
   controller state folder. Existing identities are never silently replaced.
2. Save the one-time operator token in your password manager. The dashboard does
   not persist it in browser storage. Setup alone does not start a listener or
   enroll any device.
3. Choose **This PC only** or **Network devices**, and start the listener. Network
   mode requires separate explicit LAN approval and binds all IPv4 interfaces.
   Firewall approval and certificate trust remain manual.
4. Select the destination case in Remote Devices and choose **Download agent
   installer**. Extract the ZIP on the endpoint and run its CMD file within
   30 minutes. The controller address is prefilled. Each ZIP admits one identity;
   re-running it reuses that identity. Transfer it through a trusted channel and
   treat it as a credential, not a public distributable. Older loose installer
   scripts must be replaced by this package. Manual CSR approval below and
   `Enroll Local Agent.cmd` remain alternatives. Use the saved operator
   token for shared remote access. The controller PC's local workspace is already
   trusted; it does not need a second console sign-in.

The switch manages only the controller started by this dashboard process. An
independently launched CLI controller is not terminated; a port conflict produces
an error. The panel labels its stopped state as **Stopped in this dashboard**.
Use the CLI for a specific-interface LAN bind instead of all-interface mode.

Stopping preserves identity, enrolled devices, evidence, and queued jobs. It does
not cancel endpoint collection already running; uploads wait for reconnection.
Already-running report analysis may finish; restart is held until it finishes.
Closing the settings dialog or browser tab does not stop the listener. Exiting the
dashboard process does. There is no automatic listener start after restart; the
operator still starts it intentionally from the dashboard. The main dashboard stays
available through the host address used at launch, including HTTPS LAN mode when
launched with `--host 0.0.0.0`.

Management requests use Host/Origin checks and a same-origin JSON request header.
No firewall rules or endpoint-security settings are changed.

### Command-Line Alternative

Use an NTFS folder on a trusted Windows machine. Back up the controller identity and
use BitLocker for evidence storage. ACLs restrict access; they do not encrypt evidence.
No port is opened and no firewall rule is created automatically.

From the Tyrnex application root after first-run setup:

```powershell
.\.venv\Scripts\python.exe -m pip install "cryptography>=46.0.7,<47"
.\.venv\Scripts\python.exe -m tyrnex_ai.remote init --host tyrnex-controller.example.internal --db data\TYRNEX-AI.db
.\.venv\Scripts\python.exe -m tyrnex_ai.remote serve --bind 10.10.1.20
```

Substitute the real controller hostname/IP and bind address. For a single-machine
test use `--host 127.0.0.1` and omit `--bind`. Default port is 9443. The hostname/IP
must match the certificate and agent URL. Dashboard setup generates an automatic
local unlock key and displays the operator token once. Store the operator token in
your password manager. The CA/server private keys are encrypted; the config stores
only a hash of the token. Legacy CLI setup may still ask for
`TYRNEX_CONTROLLER_PASSPHRASE`; never commit it or put it in shared launch scripts.

Trust `data\remote-controller\ca.pem` in the operator browser only after checking
its fingerprint through your trusted enrollment channel. Do not disable TLS checks.
Permit TCP/9443 only from approved endpoint networks using your normal firewall
administration. Agents connect to the HTTPS endpoint on port 9443; the operator
uses Remote devices inside the main dashboard on port 8765. The workspace uses
the same operator token and collection/report code as the optional HTTPS console.
The main dashboard remains accessible on its configured LAN interface. Other PCs
must authenticate over HTTPS. Browser sign-in uses the operator name and its token
as the password. Do not put this local pilot behind an unauthenticated loopback
reverse proxy: loopback requests are intentionally trusted as local operators.

`Remote Controller.cmd` restarts a configured loopback controller from source,
protected runtime, or private bootstrap app folders. For LAN use the explicit
`serve --bind` command above. Keep its foreground process running.

## Enroll An Endpoint

Copy `agent\tyrnex-agent.exe` from a kit to the endpoint. Its default state location
is `agent-state` beside the executable. `--state D:\Evidence\AgentState` selects a
different local NTFS state/spool location without embedding a drive letter in jobs.

```powershell
.\tyrnex-agent.exe --init https://tyrnex-controller.example.internal:9443
```

Transfer ONLY `agent-state\request.pem` to the controller through a trusted channel.
Approve that specific device on the controller:

```powershell
.\.venv\Scripts\python.exe -m tyrnex_ai.remote enroll --csr C:\Enrollment\request.pem --label HOST-01 --out C:\Enrollment\HOST-01-approved
```

Return `device.pem` and `ca.pem` from the approved directory to the endpoint's
`agent-state` directory. Do not transfer `identity.dpapi`; it is protected for the
Windows user/machine that generated it. Start the visible agent:

```powershell
.\tyrnex-agent.exe
```

Open **Remote devices** in the main dashboard. Shared remote access requires the
operator credentials described below. Enrolled devices appear with Connected, Offline, Awaiting first connection,
or Revoked status, their last contact time, and their unique device identity.
Run Host inventory to populate the host name and interface addresses.

Choose **One endpoint**, **Selected endpoints** (using endpoint checkboxes), or
**All connected endpoints**. Select the destination case and collection type,
confirm authorization, and click **Queue collection**. All-connected excludes
offline and revoked devices. An explicitly selected offline device keeps its job
until it reconnects. A bulk action accepts up to 100 devices atomically; an invalid
or revoked selection queues nothing. Retrying an unchanged request after a lost
response does not create duplicate jobs.

The Collection Queue provides per-device progress, status, page-level filtering,
cancellation, and reports. Arrow controls navigate older/newer collections in pages
of 200; the displayed range includes the total count. Reports download as Markdown,
Word, or PDF. Closing the page or changing
sections does not cancel queued work. The controller stores jobs persistently;
browser reload requires unlocking again but does not delete the job history.
Bulk submission does not imply simultaneous capture: this pilot processes one
collection and analysis at a time across the fleet.

Ctrl+C stops the agent. Closing the browser does not stop either foreground process.
Read Reports in the remote console or Findings/Remediate/Report/Cyber Triage in the
main application using the same database and case. Coverage failures are not findings
of compromise. Local listening ports are not proof of reachability from the network.

The remote report dialog downloads Markdown, Word and PDF versions of the combined
assessment (`report.md`, `report.docx`, `report.pdf`). These share the same findings,
scope, remediation and coverage warnings. `cyber-triage-report.*` files produced by
the forensic parser are separate evidence-only subreports, not substitutes for the
combined posture/forensic assessment. Older runs are not silently rewritten; rerun
an approved assessment to produce the new combined exports.

## Memory Collection

Memory is disabled locally by default even if an operator queues it. Provision your
approved signed WinPmem binary separately and set these local `agent.json` fields:

```json
{
  "url": "https://tyrnex-controller.example.internal:9443",
  "allow_memory": true,
  "winpmem": "collectors/winpmem.exe",
  "winpmem_sha256": "REPLACE_WITH_VERIFIED_64_CHARACTER_SHA256",
  "memory_max_bytes": 68719476736
}
```

The example budget is 64 GiB, not a universal RAM-size estimate. Configure at least
physical RAM and allow for physical address gaps. The agent requires the whole
budget plus 8 GiB free, enforces a controller maximum of 128 GiB, monitors free space
and output size, and refuses to treat a failed, undersized or over-budget capture as
complete. It does not truncate memory to create a "small capture."

Run the foreground agent explicitly as administrator for memory and privileged
event logs. The transport then has administrator privileges too: use only on a
trusted controlled pilot endpoint and controller. A separated privileged broker is
still required before broad service deployment. A blocked/signed-driver failure is
reported; protection is not disabled. Partial failed captures stay locally for review.

## Portable And Protected Operation

- All default runtime/state paths are relative to the application/executable, not
  the original developer profile. Controller database location is relative to its
  state folder. Stop processes before moving the whole folder.
- Moving the agent folder on the SAME Windows user/machine retains identity.
  Moving it to ANOTHER machine/user requires fresh enrollment, intentionally.
- Moving a controller to another machine needs a reachable hostname/IP matching
  its existing certificate, its protected controller state folder, and re-established
  folder ACLs and firewall policy. A changed address requires planned certificate
  and agent URL setup.
- Keep evidence and deployment credentials OUT of kits copied to other users.
  The controller/agent can operate disconnected from the internet once dependencies,
  certificates and required tools/symbols are provisioned. Volatility symbols or
  missing tools may otherwise require downloads.
- NTFS ACL protection is required for endpoint state. USB removal while running is
  unsupported; it can interrupt uploads and damage SQLite state. Not macOS/Linux.
- Compiled Python/native executables can be reverse-engineered. Packaging is not
  intellectual-property encryption. Development builds are unsigned and may trigger
  reputation/AV alerts. No AV/EDR acceptance guarantee is made.
- Protected kits record their CPython build in `runtime-python.json` and require
  matching major/minor bytecode compatibility. Their setup downloads the recorded
  version when necessary; source-based private checkouts do not have this bytecode
  restriction. A fully offline first setup still needs dependencies provisioned.
- A private bootstrap clones the configured Git branch. An unpushed local feature
  cannot appear in that fresh clone. Preview builds are not a release or proof that
  the private repository contains these changes; deploy/review the source first.

## Recovery And Boundaries

Job status separates queued, running, received, analysing, completed, warnings,
failed, interrupted and cancellation. Capture is never automatically repeated after
an uncertain crash. Upload retries use recorded offsets and full-file SHA-256 checks.
Deleting a case invalidates remote results before deleting its local data. Endpoint
offline/failed capture cleanup is not claimed as verified remote erasure. Successful
uploads retain their endpoint payload until central SHA-256 verification and
analysis finish successfully. The next agent poll removes only that job's generated
payloads after a verified completion receipt; `--once` can therefore retain files
until the next invocation. Failed/interrupted spools need operator review and
cleanup. Keep the state directory private. This pilot runs one collection-and-analysis
job at a time across enrolled devices. Other jobs stay queued until it finishes.
Parallel endpoint throughput is not qualified. Case deletion and cancellation of
central analysis can wait for the current parser to finish; capture cancellation
is cooperative through its heartbeat, not instant remote process termination.

Device certificates expire after 30 days. While running, the agent checks hourly
and renews within the final seven days using its enrolled identity and existing
public key. Lost-reply retries return the same certificate; revoking the device
invalidates both old and renewed identities. An agent that stays offline past expiry
must be re-enrolled. This is certificate renewal, not private-key rotation.
No automatic executable update, signed MSI/service installer, service privilege
broker, multi-tenant SaaS or autonomous exploit chaining is released. Stop the agent
before replacing its executable with a separately verified administrator-approved build.

The stdlib HTTPS gateway is a bounded local/pilot server, not an internet-facing
production service. The architecture's JWS tasks, hardened service hosting, automatic
key rotation, advanced collector profiles, endpoint retention policy and full
scale/performance gates remain work to do. Do not deploy publicly.

## Shared Operator Roles

Run these on the controller PC, substituting the protected state path if nondefault:

```powershell
.\.venv\Scripts\python.exe -m tyrnex_ai.remote operator-create --name analyst --role operator
.\.venv\Scripts\python.exe -m tyrnex_ai.remote operator-create --name reviewer --role viewer
.\.venv\Scripts\python.exe -m tyrnex_ai.remote operator-revoke --name reviewer
```

The token is displayed once and only its hash is saved. Creating the same name
again rotates that account's token. Viewer is read-only; operator may queue and
cancel authorized jobs; admin also controls the listener, device revocation and
case deletion. Roles apply across this installation, not per-case tenancy.
The original one-time controller token belongs to `admin`. API clients can use
`Authorization: Bearer <token>`; HTTPS browsers use name/token Basic authentication.
Browser Basic credentials may be cached until the browser session closes. Revocation
takes effect server-side immediately; closing a tab alone is not sign-out.

## Network Runner And Segmentation

Endpoint collection alone does not grant network-runner capability. On an enrolled
endpoint, with the foreground agent stopped:

```powershell
.\tyrnex-agent.exe --enable-network-runner
.\tyrnex-agent.exe
```

Run **Host inventory** to refresh advertised capabilities/interfaces. In Remote
devices choose the network-connect task and one opted-in runner. Select its assigned
IPv4 source, source/destination zones, exact target hosts/ports, authorized CIDRs,
exclusions and expected allow/deny/observe policy. Review authorization before queueing.
No target enumeration or credential use is implicit. To withdraw capability, stop
the agent and run `--disable-network-runner`, restart it, and refresh inventory.

Each plan is capped at 256 explicit hosts, 16 ports per host, 4096 pairs, 20 probes
per second, two seconds per connection and 300 seconds total. The runner resolves
and pins one IPv4 per hostname, rejects out-of-scope or ambiguous resolutions, and
binds sockets to the selected local interface. It sends no application payload.
Cancellation closes sockets cooperatively. The result includes a cleanup receipt.

A successful handshake proves reachability, not exploitation. A reachable service
with an expected-deny policy becomes a segmentation finding with the original result
path/hash. Refused, timed-out, missing and cancelled probes do not prove firewall
enforcement. **Retest same scope** reuses the original device, case instance and plan;
it does not silently change source perspective. TCP non-rediscovery remains unresolved,
not a confirmed fix. Shared JSON, Markdown, Word/PDF reports retain this distinction.

The versioned catalog is available at the authenticated operator `catalog` endpoint.
Its current network check is `tcp.connect` version `1.0.0`. It is not an autonomous
multi-hop penetration-testing engine. Real multi-subnet qualification is still required.

## Verification

### Removal and interrupted publication

Revoking or deleting a device blocks subsequent authenticated requests and cancels
queued/running collections without waiting for report analysis. SQLite serializes
this change with in-flight admission checks. Renewed credentials and consumed
enrollment invitations for that device are removed as well. Already received
evidence and case reports remain, and accepted evidence can finish analysis.
Neither operation uninstalls the agent, undoes an endpoint action, nor guarantees
that an action already dispatched to an offline endpoint has stopped.

Case deletion remains coordinated with report publication to prevent a report
from recreating a deleted case. Each publication gate has a bounded 30-second
wait shared between its thread and filesystem locks. A busy error leaves the
case intact; retry after the current publication finishes.

On controller startup, an interrupted report is recovered only when the current
case generation, accepted result, saved assessment, outcome and report file
hashes match its publication marker. Exactly one saved assessment must match.
Failed action receipts remain failed. Recovery never dispatches the endpoint
action again. Missing, changed, ambiguous or uncommitted publication data stays
unavailable for automatic recovery and requires evidence review. This is not a
cross-database/filesystem atomic transaction or a substitute for backups.

Event-log collection first exports directly into the agent's evidence spool. Native
path errors (3 or 206) trigger one fallback through a temporary directory restricted
to the current user and SYSTEM. The original EVTX bytes are copied into the spool;
the collection method is recorded in provenance and the shared report. Access-denied
errors do not trigger an elevation or permission bypass. Normal completion removes
the owned staging file/directory; a process or host crash can leave private evidence
in the temporary directory, which must be handled under the evidence retention policy.

```powershell
.\.venv\Scripts\python.exe -m pytest tests/test_remote_controller.py tests/test_host_assessment.py tests/test_storage.py -q
.\.venv\Scripts\python.exe scripts\build_remote_agent.py
cd agent
go test ./...
```

`scripts/test_remote_localhost.py --authorized --output <new-directory>` performs
real inventory/posture/EVTX collection into an isolated QA case, verifies shared
reports, checks the non-opted-in memory failure, tests desktop/mobile UI and moves
the agent folder on the same host. It does not perform an elevated RAM acquisition
or certify all supported Windows versions/EDR products. Never label these as passed
without their separate live tests.

`scripts/qa_local_network_runner.py --authorized --address <local-IPv4> --output
<new-directory>` tests a native agent against a temporary listener on that same
assigned LAN address. It does not scan neighboring hosts or qualify network zones.
