$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$tools = Join-Path $root "tools"
$bin = Join-Path $tools "bin"
New-Item -ItemType Directory -Path $bin -Force | Out-Null

function Find-MsfConsole {
  $localLauncher = Join-Path $bin "msfconsole.cmd"
  $candidates = @(
    (Join-Path $tools "metasploit-framework\bin\msfconsole.bat"),
    (Join-Path $tools "metasploit-framework\bin\msfconsole.cmd"),
    (Join-Path $tools "metasploit-framework\embedded\framework\msfconsole.bat"),
    "C:\metasploit-framework\bin\msfconsole.bat",
    "C:\metasploit-framework\embedded\framework\msfconsole.bat",
    "$env:ProgramFiles\Metasploit Framework\bin\msfconsole.bat",
    "$env:ProgramFiles\Rapid7\Metasploit\bin\msfconsole.bat",
    "$env:ProgramFiles(x86)\Metasploit Framework\bin\msfconsole.bat",
    "$env:ProgramFiles(x86)\Rapid7\Metasploit\bin\msfconsole.bat"
  )
  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate)) {
      return (Resolve-Path -LiteralPath $candidate).Path
    }
  }
  $cmd = Get-Command msfconsole.bat, msfconsole.cmd, msfconsole -ErrorAction SilentlyContinue |
    Where-Object { $_.Source -and ((Resolve-Path -LiteralPath $_.Source -ErrorAction SilentlyContinue).Path -ne (Resolve-Path -LiteralPath $localLauncher -ErrorAction SilentlyContinue).Path) } |
    Select-Object -First 1
  if ($cmd) { return $cmd.Source }
  return $null
}

function Try-WingetInstall {
  param([string[]]$Ids)
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    return $false
  }
  foreach ($id in $Ids) {
    Write-Host "Trying winget install $id ..."
    winget install --id $id --source winget --exact --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -eq 0) { return $true }
  }
  return $false
}

function Test-IsAdmin {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Restart-Elevated {
  $script = Join-Path $root "Install Metasploit Integration.ps1"
  $args = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ('"' + $script + '"'))
  Write-Host "Opening an Administrator PowerShell prompt through UAC..."
  try {
    Start-Process -FilePath "powershell.exe" -ArgumentList $args -Verb RunAs
    return $true
  } catch {
    Write-Host "Could not open elevated installer: $($_.Exception.Message)" -ForegroundColor Yellow
    return $false
  }
}

function Try-OfficialMsiInstall {
  $downloadUrl = "https://windows.metasploit.com/metasploitframework-latest.msi"
  $downloadDir = Join-Path $root "downloads"
  $installer = Join-Path $downloadDir "metasploitframework-latest.msi"
  $logPath = Join-Path $downloadDir "metasploit-install.log"
  $installLocation = $tools

  if (-not (Test-IsAdmin)) {
    Write-Host "Official MSI install needs Administrator rights." -ForegroundColor Yellow
    Write-Host "TYRNEX-AI will now request elevation. Approve the Windows UAC prompt to continue the MSI install."
    if (Restart-Elevated) {
      Write-Host "Elevated installer launched. Continue in the Administrator window; this non-admin window will stop here." -ForegroundColor Green
      exit 0
    }
    Write-Host "If UAC did not appear, right-click Install Metasploit Integration.cmd and choose Run as administrator, or install manually from:"
    Write-Host $downloadUrl
    return $false
  }

  New-Item -ItemType Directory -Path $downloadDir -Force | Out-Null
  Write-Host "Downloading official Metasploit Framework MSI..."
  Invoke-WebRequest -UseBasicParsing -Uri $downloadUrl -OutFile $installer
  Write-Host "Installing Metasploit Framework into $installLocation ..."
  $process = Start-Process -FilePath "msiexec.exe" -ArgumentList @(
    "/i", ('"' + $installer + '"'),
    "/qn",
    "/norestart",
    "/log", ('"' + $logPath + '"'),
    ("INSTALLLOCATION=" + '"' + $installLocation + '"')
  ) -Wait -PassThru
  if ($process.ExitCode -eq 0) {
    return $true
  }
  Write-Host "Metasploit MSI install failed with exit code $($process.ExitCode). Log: $logPath" -ForegroundColor Yellow
  return $false
}

Write-Host "TYRNEX-AI Metasploit integration" -ForegroundColor Cyan
if (-not (Test-Path -LiteralPath (Join-Path $root "tyrnex_ai"))) {
  Write-Host "This does not look like a TYRNEX-AI runtime folder." -ForegroundColor Red
  exit 1
}

$msf = Find-MsfConsole
if (-not $msf) {
  Write-Host "Metasploit was not found locally. Trying official winget package IDs..."
  Try-WingetInstall @("Rapid7.Metasploit", "Rapid7.MetasploitFramework", "Metasploit.MetasploitFramework") | Out-Null
  $msf = Find-MsfConsole
}
if (-not $msf) {
  Write-Host "Winget did not provide Metasploit. Trying the official Rapid7 Windows MSI fallback..."
  Try-OfficialMsiInstall | Out-Null
  $msf = Find-MsfConsole
}
if (-not $msf) {
  Write-Host "Metasploit is still not installed." -ForegroundColor Yellow
  Write-Host "Install from https://www.metasploit.com/download or https://windows.metasploit.com/metasploitframework-latest.msi, then rerun this file."
  Write-Host "Expected: msfconsole on PATH, or under tools\metasploit-framework."
  exit 2
}

$launcher = Join-Path $bin "msfconsole.cmd"
Set-Content -LiteralPath $launcher -Encoding ASCII -Value @(
  "@echo off",
  ('"' + $msf + '" %*')
)

Write-Host "Metasploit linked into: $launcher" -ForegroundColor Green
& (Join-Path $root "Check Optional Integrations.ps1")
