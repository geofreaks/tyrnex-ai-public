$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$python = Join-Path $root ".venv\Scripts\python.exe"
function Test-PythonRuntime {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { return $false }
  try {
    & $Path -c "import sys; print(sys.executable)" *> $null
    return $LASTEXITCODE -eq 0
  } catch {
    return $false
  }
}
if (-not (Test-PythonRuntime $python)) {
  Write-Host "Runtime is missing, broken, or was moved from another machine. Running first-run setup..." -ForegroundColor Yellow
  & (Join-Path $root "Run This First.ps1") -NoStart -SkipToolBootstrap
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
if (-not (Test-PythonRuntime $python)) {
  Write-Host "Runtime is not installed yet. Run 'Run This First.cmd' after installing Python 3.11+." -ForegroundColor Red
  exit 1
}
$env:PYTHONPATH = "$root;$env:PYTHONPATH"
Write-Host "Installing/updating all bootstrap-supported TYRNEX-AI tools..."
& $python -m tyrnex_ai.cli bootstrap-tools
if ($LASTEXITCODE -ne 0) {
  Write-Host "Some bootstrap-supported tools could not be installed automatically. Continuing to optional integration checks." -ForegroundColor Yellow
  $global:LASTEXITCODE = 0
}
Write-Host "Installing/updating OWASP ZAP wrappers..."
& (Join-Path $root "Install OWASP ZAP Integration.ps1")
if ($LASTEXITCODE -ne 0) {
  Write-Host "OWASP ZAP wrapper setup reported an issue. Use Check Optional Integrations for details." -ForegroundColor Yellow
  $global:LASTEXITCODE = 0
}
Write-Host "Optional Metasploit check/link..."
& (Join-Path $root "Install Metasploit Integration.ps1")
if ($LASTEXITCODE -ne 0) {
  Write-Host "Metasploit is optional and may require Administrator MSI install. Use Install Metasploit Integration.cmd when ready." -ForegroundColor Yellow
  $global:LASTEXITCODE = 0
}
