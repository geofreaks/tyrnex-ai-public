param(
  [switch]$SkipLaunchProbe,
  [int]$ProbeTimeoutSeconds = 12,
  [string]$OutDir = ""
)

$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $OutDir) {
  $OutDir = Join-Path $root "data\compatibility"
}
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$stamp = Get-Date -Format "yyyyMMddTHHmmss"
$textReport = Join-Path $OutDir "security-compatibility-$stamp.txt"
$jsonReport = Join-Path $OutDir "security-compatibility-$stamp.json"

$script:checks = New-Object System.Collections.Generic.List[object]
$script:toolRows = New-Object System.Collections.Generic.List[object]
$script:securityRows = New-Object System.Collections.Generic.List[object]
$script:recommendations = New-Object System.Collections.Generic.List[string]

function Add-Check {
  param([string]$Area, [string]$Name, [string]$Status, [string]$Detail = "", [string]$Action = "")
  $script:checks.Add([pscustomobject]@{
    area = $Area
    name = $Name
    status = $Status
    detail = $Detail
    action = $Action
  }) | Out-Null
  if ($Action -and $Status -in @("fail", "warn")) {
    $script:recommendations.Add($Action) | Out-Null
  }
}

function Test-IsAdmin {
  try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  } catch {
    return $false
  }
}

function Test-PythonRuntime {
  param([string]$Path)
  if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return $false }
  try {
    & $Path -c "import sys; print(sys.version)" *> $null
    return $LASTEXITCODE -eq 0
  } catch {
    return $false
  }
}

function Resolve-TyrnexPython {
  $candidate = Join-Path $root ".venv\Scripts\python.exe"
  if (Test-PythonRuntime $candidate) { return $candidate }
  $runtime = Join-Path $root ".runtime\python\python.exe"
  if (Test-PythonRuntime $runtime) { return $runtime }
  $cmd = Get-Command python -ErrorAction SilentlyContinue
  if ($cmd -and (Test-PythonRuntime $cmd.Source)) { return $cmd.Source }
  return $null
}

function Invoke-Probe {
  param(
    [string]$FilePath,
    [string[]]$Arguments,
    [int]$TimeoutSeconds
  )
  $tmpOut = Join-Path $env:TEMP ("tyrnex-compat-out-" + [guid]::NewGuid().ToString("N") + ".txt")
  $tmpErr = Join-Path $env:TEMP ("tyrnex-compat-err-" + [guid]::NewGuid().ToString("N") + ".txt")
  try {
    $proc = Start-Process -FilePath $FilePath -ArgumentList $Arguments -NoNewWindow -PassThru -RedirectStandardOutput $tmpOut -RedirectStandardError $tmpErr
    if (-not $proc.WaitForExit($TimeoutSeconds * 1000)) {
      try { $proc.Kill() } catch {}
      return [pscustomobject]@{ status = "warn"; code = $null; output = "Timed out after $TimeoutSeconds second(s)." }
    }
    $out = ""
    if (Test-Path -LiteralPath $tmpOut) { $out += (Get-Content -LiteralPath $tmpOut -Raw -ErrorAction SilentlyContinue) }
    if (Test-Path -LiteralPath $tmpErr) { $out += "`n" + (Get-Content -LiteralPath $tmpErr -Raw -ErrorAction SilentlyContinue) }
    $out = ($out -replace "\s+", " ").Trim()
    if ($out.Length -gt 500) { $out = $out.Substring(0, 500) + "..." }
    $blockedPattern = "No Python at|not recognized as an internal or external command|The system cannot find the path specified|requested operation requires elevation|requires elevation|Access is denied|blocked by group policy|This app has been blocked"
    $status = if ($out -match $blockedPattern) { "fail" } elseif ($proc.ExitCode -eq 0 -or $out.Length -gt 0) { "pass" } else { "warn" }
    return [pscustomobject]@{ status = $status; code = $proc.ExitCode; output = $out }
  } catch {
    return [pscustomobject]@{ status = "fail"; code = $null; output = $_.Exception.Message }
  } finally {
    Remove-Item -LiteralPath $tmpOut -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $tmpErr -Force -ErrorAction SilentlyContinue
  }
}

function Get-ProbeArgs {
  param([string]$Tool)
  switch -Regex ($Tool) {
    "^(nmap|naabu|httpx|katana|subfinder|dnsx|amass|gitleaks|trivy|semgrep|sqlmap|schemathesis|prowler|scout|hashcat|john|hayabusa|chainsaw|velociraptor|avml|SharpHound|azurehound|bloodhound-cli|nxc)$" { return @("--version") }
    "^(nuclei)$" { return @("-version") }
    "^(msfconsole)$" { return @("-v") }
    "^(searchsploit)$" { return @("-h") }
    "^(zap-baseline.py|zap-full-scan.py|kube-hunter|ldapdomaindump|secretsdump.py|GetNPUsers.py|GetUserSPNs.py|volatility3|EvtxECmd|PECmd|LECmd|JLECmd|RBCmd|MFTECmd|AmcacheParser|AppCompatCacheParser|SrumECmd|RECmd|winpmem|kape)$" { return @("--help") }
    default { return @("--help") }
  }
}

function Get-ZoneIdentifier {
  param([string]$Path)
  try {
    $stream = Get-Item -LiteralPath $Path -Stream Zone.Identifier -ErrorAction SilentlyContinue
    if ($stream) {
      return "present"
    }
  } catch {}
  return "none"
}

function Test-PathWritable {
  param([string]$Path)
  try {
    New-Item -ItemType Directory -Force -Path $Path | Out-Null
    $probe = Join-Path $Path ("write-test-" + [guid]::NewGuid().ToString("N") + ".tmp")
    "ok" | Set-Content -LiteralPath $probe -Encoding ASCII
    Remove-Item -LiteralPath $probe -Force
    return $true
  } catch {
    return $false
  }
}

Write-Host "TYRNEX-AI Security Compatibility Check" -ForegroundColor Cyan
Write-Host "Read-only compatibility audit. This does not disable AV, EDR, XDR, Defender, or firewall controls."
Write-Host ""

$isWindows = $PSVersionTable.Platform -eq "Win32NT" -or [string]::IsNullOrWhiteSpace($PSVersionTable.Platform)
Add-Check "system" "Windows platform" $(if ($isWindows) { "pass" } else { "fail" }) "$([Environment]::OSVersion.VersionString)" $(if ($isWindows) { "" } else { "Run TYRNEX-AI on a supported Windows 10/11 x64 host or VM." })
Add-Check "system" "PowerShell" "pass" "$($PSVersionTable.PSVersion)"
$isAdmin = Test-IsAdmin
Add-Check "system" "Administrator session" $(if ($isAdmin) { "pass" } else { "warn" }) $(if ($isAdmin) { "Elevated" } else { "Not elevated" }) "Run as Administrator for WinPmem memory capture, KAPE sync/collection, and privileged host checks."

foreach ($folder in @("data", "tools", "tools\bin", "data\cases", "data\compatibility")) {
  $path = Join-Path $root $folder
  $ok = Test-PathWritable $path
  Add-Check "filesystem" "$folder writable" $(if ($ok) { "pass" } else { "fail" }) $path $(if ($ok) { "" } else { "Move the kit to a writable local/USB folder or fix folder permissions." })
}

$python = Resolve-TyrnexPython
if ($python) {
  Add-Check "runtime" "Python runtime" "pass" $python
  $env:PYTHONPATH = "$root;$env:PYTHONPATH"
} else {
  Add-Check "runtime" "Python runtime" "fail" "No usable .venv, .runtime, or PATH Python was found." "Run Run This First.cmd while online, or install Python 3.11+."
}

$items = @()
if ($python) {
  $code = "import json; from tyrnex_ai.setup_check import setup_items, is_kapefiles_ready_item; [print(json.dumps(dict(tool=i.tool, available=i.available, optional=i.optional, bundled=i.bundled, path=i.path, purpose=i.purpose, install_hint=i.install_hint, kapefiles_ready=is_kapefiles_ready_item(i)))) for i in setup_items()]"
  try {
    $jsonLines = @(& $python -c $code)
    foreach ($line in $jsonLines) {
      if (-not [string]::IsNullOrWhiteSpace($line)) {
        $items += ($line | ConvertFrom-Json)
      }
    }
    if ($items.Count -gt 0) {
      Add-Check "runtime" "TYRNEX import and doctor model" "pass" "$($items.Count) tools enumerated"
    } else {
      Add-Check "runtime" "TYRNEX import and doctor model" "fail" "0 tools enumerated" "Run Run This First.cmd to repair the local runtime."
    }
  } catch {
    Add-Check "runtime" "TYRNEX import and doctor model" "fail" $_.Exception.Message "Run Run This First.cmd to repair the local runtime."
  }
}

$defenderAvailable = $false
try {
  $mp = Get-MpComputerStatus -ErrorAction Stop
  $defenderAvailable = $true
  $detail = "AV=$($mp.AntivirusEnabled) RTP=$($mp.RealTimeProtectionEnabled) Behavior=$($mp.BehaviorMonitorEnabled) IOAV=$($mp.IoavProtectionEnabled) NIS=$($mp.NISEnabled)"
  $status = if ($mp.AntivirusEnabled -and $mp.RealTimeProtectionEnabled) { "pass" } else { "warn" }
  $action = "Confirm another managed AV/EDR is active if Defender is disabled."
  Add-Check "security" "Microsoft Defender status" $status $detail $action
  $script:securityRows.Add([pscustomobject]@{ name = "Defender"; status = $status; detail = $detail }) | Out-Null
} catch {
  Add-Check "security" "Microsoft Defender status" "warn" "Get-MpComputerStatus unavailable: $($_.Exception.Message)" "If this host uses third-party EDR, confirm it allows TYRNEX tools or use a lab VM."
}

try {
  $pref = Get-MpPreference -ErrorAction Stop
  $rootPrefix = (Resolve-Path -LiteralPath $root).Path
  $pathHits = @($pref.ExclusionPath | Where-Object { $_ -and ($rootPrefix.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) -or $_.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) })
  $procHits = @($pref.ExclusionProcess | Where-Object { $_ -match "nmap|nuclei|msf|winpmem|kape|hayabusa|chainsaw" })
  $detail = "ControlledFolderAccess=$($pref.EnableControlledFolderAccess); relevant path exclusions=$($pathHits.Count); relevant process exclusions=$($procHits.Count)"
  Add-Check "security" "Defender preferences" "pass" $detail
} catch {
  Add-Check "security" "Defender preferences" "warn" $_.Exception.Message "Run elevated for fuller Defender compatibility details."
}

try {
  $detections = @(Get-MpThreatDetection -ErrorAction Stop | Where-Object { $_.Resources -match [regex]::Escape($root) } | Select-Object -First 20)
  $status = if ($detections.Count -gt 0) { "warn" } else { "pass" }
  Add-Check "security" "Defender detections touching TYRNEX" $status "$($detections.Count) recent detection(s) reference this folder." $(if ($detections.Count -gt 0) { "Open Windows Security Protection History and restore/allow only verified TYRNEX tool files if needed." } else { "" })
} catch {
  Add-Check "security" "Defender detections touching TYRNEX" "warn" "Threat history unavailable: $($_.Exception.Message)" "Check Windows Security Protection History if tools are missing or blocked."
}

try {
  $dg = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard -ErrorAction Stop
  Add-Check "security" "WDAC / Device Guard signal" "pass" "SecurityServicesRunning=$($dg.SecurityServicesRunning -join ',') CodeIntegrityPolicyEnforcementStatus=$($dg.CodeIntegrityPolicyEnforcementStatus)"
} catch {
  Add-Check "security" "WDAC / Device Guard signal" "warn" "Unavailable: $($_.Exception.Message)" "If enterprise WDAC/App Control is enabled, allow signed/approved TYRNEX tool paths through policy."
}

try {
  $policies = Get-AppLockerPolicy -Effective -ErrorAction Stop
  $ruleCount = @($policies.RuleCollections | ForEach-Object { $_.Count }).Count
  Add-Check "security" "AppLocker effective policy" "pass" "$ruleCount rule collection count(s) visible."
} catch {
  Add-Check "security" "AppLocker effective policy" "warn" "Unavailable or not configured: $($_.Exception.Message)" "If AppLocker is enforced, approve TYRNEX tools by publisher/hash/path."
}

foreach ($item in $items) {
  $tool = [string]$item.tool
  $path = [string]$item.path
  $available = [bool]$item.available
  $optional = [bool]$item.optional
  $row = [ordered]@{
    tool = $tool
    status = "missing"
    optional = $optional
    bundled = [bool]$item.bundled
    path = $path
    size = $null
    sha256 = $null
    motw = "n/a"
    launch_probe = if ($SkipLaunchProbe) { "skipped" } else { "not_run" }
    detail = ""
    action = ""
  }
  if (-not $available -or -not $path) {
    $row.status = if ($optional -or [bool]$item.kapefiles_ready) { "optional-missing" } else { "missing" }
    $row.detail = [string]$item.install_hint
    $row.action = if ($optional) { "Install only if you need this workflow." } else { [string]$item.install_hint }
    $script:toolRows.Add([pscustomobject]$row) | Out-Null
    continue
  }
  if (-not (Test-Path -LiteralPath $path)) {
    $row.status = "missing-path"
    $row.detail = "Doctor resolved a path that no longer exists."
    $row.action = "Run Check / Install Tools or Run This First.cmd to repair the tool bundle."
    $script:toolRows.Add([pscustomobject]$row) | Out-Null
    continue
  }
  try {
    $file = Get-Item -LiteralPath $path -ErrorAction Stop
    $row.size = $file.Length
    if (-not $file.PSIsContainer) {
      $row.sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
      $row.motw = Get-ZoneIdentifier $path
    }
    $row.status = "present"
  } catch {
    $row.status = "warn"
    $row.detail = $_.Exception.Message
  }
  if (-not $SkipLaunchProbe) {
    if ($tool -in @("zap-proxy")) {
      $row.launch_probe = "skipped: proxy GUI/daemon workflow"
    } elseif ($tool -eq "kape" -and (Split-Path -Leaf $path).ToLowerInvariant() -eq "gkape.exe") {
      $row.launch_probe = "skipped: GUI binary; kape.exe checked by doctor when present"
    } else {
      $probe = Invoke-Probe -FilePath $path -Arguments (Get-ProbeArgs $tool) -TimeoutSeconds $ProbeTimeoutSeconds
      $row.launch_probe = "$($probe.status): exit=$($probe.code) $($probe.output)"
      if ($probe.status -eq "fail") {
        if ($optional -and $probe.output -match "elevation|Access is denied") {
          $row.status = "warn"
          $row.action = "Run this compatibility check and the matching workflow as Administrator when using this optional tool."
        } else {
          $row.status = "blocked"
          $row.action = "Review AV/EDR/AppLocker/WDAC logs for this exact path, then reinstall or allow the verified binary."
        }
      } elseif ($probe.status -eq "warn" -and $row.status -eq "present") {
        $row.status = "warn"
        $row.action = "Run this tool manually with --help/--version and check security product logs if it fails."
      } else {
        $row.status = "runnable"
      }
    }
  }
  if ($row.motw -eq "present" -and $row.status -in @("present", "runnable")) {
    $row.status = "warn"
    $row.action = "File has Mark-of-the-Web. If Windows blocks it, use Unblock-File on this verified binary."
  }
  $script:toolRows.Add([pscustomobject]$row) | Out-Null
}

$toolTotal = $script:toolRows.Count
$ready = @($script:toolRows | Where-Object { $_.status -in @("runnable", "present") }).Count
$warn = @($script:toolRows | Where-Object { $_.status -eq "warn" }).Count
$blocked = @($script:toolRows | Where-Object { $_.status -eq "blocked" -and -not $_.optional }).Count
$blockedOptional = @($script:toolRows | Where-Object { $_.status -eq "blocked" -and $_.optional }).Count
$missingRequired = @($script:toolRows | Where-Object { $_.status -in @("missing", "missing-path") -and -not $_.optional }).Count
$missingOptional = @($script:toolRows | Where-Object { $_.status -like "optional*" }).Count

$overall = if ($blocked -or $missingRequired) { "needs-attention" } elseif ($warn -or $missingOptional -or $blockedOptional) { "usable-with-warnings" } else { "ready" }
Add-Check "summary" "Overall compatibility" $(if ($overall -eq "ready") { "pass" } elseif ($overall -eq "usable-with-warnings") { "warn" } else { "fail" }) "ready=$ready/$toolTotal warn=$warn blocked_required=$blocked blocked_optional=$blockedOptional missing_required=$missingRequired optional_missing=$missingOptional"

$counts = New-Object PSObject
$counts | Add-Member -NotePropertyName tools_total -NotePropertyValue $toolTotal
$counts | Add-Member -NotePropertyName tools_ready -NotePropertyValue $ready
$counts | Add-Member -NotePropertyName warnings -NotePropertyValue $warn
$counts | Add-Member -NotePropertyName blocked_required -NotePropertyValue $blocked
$counts | Add-Member -NotePropertyName blocked_optional -NotePropertyValue $blockedOptional
$counts | Add-Member -NotePropertyName missing_required -NotePropertyValue $missingRequired
$counts | Add-Member -NotePropertyName optional_missing -NotePropertyValue $missingOptional

$payload = New-Object PSObject
$payload | Add-Member -NotePropertyName generated_at -NotePropertyValue (Get-Date).ToString("o")
$payload | Add-Member -NotePropertyName root -NotePropertyValue $root
$payload | Add-Member -NotePropertyName report_path -NotePropertyValue $textReport
$payload | Add-Member -NotePropertyName json_path -NotePropertyValue $jsonReport
$payload | Add-Member -NotePropertyName overall -NotePropertyValue $overall
$payload | Add-Member -NotePropertyName counts -NotePropertyValue $counts
$payload | Add-Member -NotePropertyName checks -NotePropertyValue ([object[]]$script:checks.ToArray())
$payload | Add-Member -NotePropertyName tools -NotePropertyValue ([object[]]$script:toolRows.ToArray())
$payload | Add-Member -NotePropertyName recommendations -NotePropertyValue ([object[]]@($script:recommendations | Select-Object -Unique))

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("TYRNEX-AI Security Compatibility Check") | Out-Null
$lines.Add("Generated: $(Get-Date)") | Out-Null
$lines.Add("Root: $root") | Out-Null
$lines.Add("Overall: $overall") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("Summary") | Out-Null
$lines.Add("  Tools ready: $ready/$toolTotal") | Out-Null
$lines.Add("  Warnings: $warn") | Out-Null
$lines.Add("  Blocked required: $blocked") | Out-Null
$lines.Add("  Blocked optional: $blockedOptional") | Out-Null
$lines.Add("  Missing required: $missingRequired") | Out-Null
$lines.Add("  Missing optional: $missingOptional") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("System and security checks") | Out-Null
foreach ($check in $script:checks) {
  $lines.Add(("  [{0}] {1}/{2}: {3}" -f $check.status.ToUpperInvariant(), $check.area, $check.name, $check.detail)) | Out-Null
  if ($check.action) { $lines.Add("       Action: $($check.action)") | Out-Null }
}
$lines.Add("") | Out-Null
$lines.Add("Tool compatibility") | Out-Null
foreach ($row in $script:toolRows | Sort-Object status, tool) {
  $lines.Add(("  [{0}] {1} optional={2} bundled={3}" -f $row.status.ToUpperInvariant(), $row.tool, $row.optional, $row.bundled)) | Out-Null
  if ($row.path) { $lines.Add("       Path: $($row.path)") | Out-Null }
  if ($row.sha256) { $lines.Add("       SHA256: $($row.sha256)") | Out-Null }
  if ($row.launch_probe) { $lines.Add("       Probe: $($row.launch_probe)") | Out-Null }
  if ($row.detail) { $lines.Add("       Detail: $($row.detail)") | Out-Null }
  if ($row.action) { $lines.Add("       Action: $($row.action)") | Out-Null }
}
$lines.Add("") | Out-Null
$lines.Add("Recommended next actions") | Out-Null
$uniqueRecs = @($script:recommendations | Select-Object -Unique)
if ($uniqueRecs.Count) {
  foreach ($rec in $uniqueRecs) { $lines.Add("  - $rec") | Out-Null }
} else {
  $lines.Add("  - No compatibility blockers detected.") | Out-Null
}
$lines.Add("") | Out-Null
$lines.Add("This script is read-only. It does not disable security controls or create exclusions.") | Out-Null

$lines | Set-Content -LiteralPath $textReport -Encoding UTF8
$payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jsonReport -Encoding UTF8

Write-Host "Overall: $overall"
Write-Host "Tools ready: $ready/$toolTotal; warnings=$warn; blocked=$blocked; missing_required=$missingRequired; optional_missing=$missingOptional"
Write-Host "Text report: $textReport" -ForegroundColor Cyan
Write-Host "JSON report: $jsonReport" -ForegroundColor Cyan
if ($overall -eq "ready") {
  Write-Host "Compatibility check complete: ready." -ForegroundColor Green
  exit 0
}
if ($overall -eq "usable-with-warnings") {
  Write-Host "Compatibility check complete: usable with warnings." -ForegroundColor Yellow
  exit 0
}
Write-Host "Compatibility check complete: attention required." -ForegroundColor Red
exit 1
