$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$tools = Join-Path $root "tools"
$bin = Join-Path $tools "bin"
New-Item -ItemType Directory -Path $bin -Force | Out-Null

function Find-ZapHome {
  $candidates = @(
    (Join-Path $tools "zap"),
    (Join-Path $tools "owasp-zap"),
    "$env:ProgramFiles\ZAP",
    "$env:ProgramFiles\OWASP\Zed Attack Proxy",
    "$env:ProgramFiles\OWASP ZAP",
    "$env:ProgramFiles(x86)\ZAP",
    "$env:ProgramFiles(x86)\OWASP\Zed Attack Proxy",
    "$env:ProgramFiles(x86)\OWASP ZAP"
  )
  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate)) {
      $zap = Get-ChildItem -LiteralPath $candidate -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -in @("zap.bat", "zap.sh", "zap.exe") } |
        Select-Object -First 1
      if ($zap) { return $zap.DirectoryName }
    }
  }
  $cmd = Get-Command zap.bat, zap.sh, zap.exe -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($cmd) { return (Split-Path -Parent $cmd.Source) }
  return $null
}

function Try-WingetInstall {
  param([string[]]$Ids)
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    return $false
  }
  foreach ($id in $Ids) {
    Write-Host "Trying winget install $id ..."
    winget install --id $id --source winget --exact --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -eq 0) { return $true }
  }
  return $false
}

function Write-PythonWrapper {
  param([string]$Path, [string]$Name)
  $python = Join-Path $root '.venv\Scripts\python.exe'
  if (-not (Test-Path -LiteralPath $python)) { throw 'Run This First.cmd to prepare the runtime.' }
  Push-Location $root
  try {
    & $python -c 'import sys; from pathlib import Path; from tyrnex_ai.bootstrap_tools import _bootstrap_zap_scan; print(_bootstrap_zap_scan(sys.argv[1], Path(sys.argv[2]), True))' $Name $bin
    if ($LASTEXITCODE -ne 0) { throw 'ZAP adapter setup failed' }
  } finally { Pop-Location }
}

Write-Host "TYRNEX-AI OWASP ZAP integration" -ForegroundColor Cyan
if (-not (Test-Path -LiteralPath (Join-Path $root "tyrnex_ai"))) {
  Write-Host "This does not look like a TYRNEX-AI runtime folder." -ForegroundColor Red
  exit 1
}

$zapHome = Find-ZapHome
if (-not $zapHome) {
  Write-Host "OWASP ZAP was not found locally. Trying official winget package IDs..."
  Try-WingetInstall @("ZAP.ZAP", "OWASP.ZAP", "Zaproxy.ZAP") | Out-Null
  $zapHome = Find-ZapHome
}
if (-not $zapHome) {
  Write-Host "OWASP ZAP app was not found after install attempts." -ForegroundColor Yellow
  Write-Host "Install ZAP and its Java runtime, then run zap-baseline.py.cmd --check to verify readiness."
  $zapHome = ""
}

$baseline = Join-Path $bin "zap-baseline.py"
$full = Join-Path $bin "zap-full-scan.py"
Write-PythonWrapper $baseline "zap-baseline.py"
Write-PythonWrapper $full "zap-full-scan.py"

$zapLauncher = Join-Path $bin "zap.sh"
if ($zapHome) {
  $zapBat = Join-Path $zapHome "zap.bat"
  $zapExe = Join-Path $zapHome "zap.exe"
  $target = if (Test-Path -LiteralPath $zapBat) { $zapBat } elseif (Test-Path -LiteralPath $zapExe) { $zapExe } else { "" }
  if ($target) {
    Set-Content -LiteralPath $zapLauncher -Encoding ASCII -Value @(
      "@echo off",
      ('"' + $target + '" %*')
    )
  }
}
if (-not (Test-Path -LiteralPath $zapLauncher)) {
  Set-Content -LiteralPath $zapLauncher -Encoding ASCII -Value @(
    "@echo off",
    "echo OWASP ZAP app is not installed. Install ZAP from https://www.zaproxy.org/download/ for live proxy mode.",
    "exit /b 0"
  )
}
Copy-Item -LiteralPath $zapLauncher -Destination (Join-Path $bin "zap.bat") -Force

Write-Host "ZAP Automation Framework adapters installed into: $bin" -ForegroundColor Green
& (Join-Path $bin 'zap-baseline.py.cmd') --check
& (Join-Path $root "Check Optional Integrations.ps1")
