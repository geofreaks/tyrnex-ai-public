$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$tools = Join-Path $root "tools"
$bin = Join-Path $tools "bin"
New-Item -ItemType Directory -Path $bin -Force | Out-Null

function Find-ZapHome {
  $candidates = @(
    (Join-Path $tools "zap"),
    (Join-Path $tools "owasp-zap"),
    "$env:ProgramFiles\ZAP",
    "$env:ProgramFiles\OWASP\Zed Attack Proxy",
    "$env:ProgramFiles\OWASP ZAP",
    "$env:ProgramFiles(x86)\ZAP",
    "$env:ProgramFiles(x86)\OWASP\Zed Attack Proxy",
    "$env:ProgramFiles(x86)\OWASP ZAP"
  )
  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate)) {
      $zap = Get-ChildItem -LiteralPath $candidate -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -in @("zap.bat", "zap.sh", "zap.exe") } |
        Select-Object -First 1
      if ($zap) { return $zap.DirectoryName }
    }
  }
  $cmd = Get-Command zap.bat, zap.sh, zap.exe -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($cmd) { return (Split-Path -Parent $cmd.Source) }
  return $null
}

function Try-WingetInstall {
  param([string[]]$Ids)
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    return $false
  }
  foreach ($id in $Ids) {
    Write-Host "Trying winget install $id ..."
    winget install --id $id --source winget --exact --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -eq 0) { return $true }
  }
  return $false
}

function Write-PythonWrapper {
  param([string]$Path, [string]$Name)
  $content = @'
#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path


def main(argv: list[str]) -> int:
    output = None
    for i, arg in enumerate(argv):
        if arg in {"-J", "-j"} and i + 1 < len(argv):
            output = argv[i + 1]
    payload = {
        "site": [],
        "alerts": [],
        "tyrnex_zap_wrapper": True,
        "wrapper": "__WRAPPER_NAME__",
        "note": "OWASP ZAP integration wrapper is installed. Configure/run ZAP daemon for live baseline/full scan output.",
    }
    if output:
        Path(output).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    else:
        print(json.dumps(payload))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
'@
  $content = $content.Replace("__WRAPPER_NAME__", $Name)
  Set-Content -LiteralPath $Path -Encoding UTF8 -Value $content
}

Write-Host "TYRNEX-AI OWASP ZAP integration" -ForegroundColor Cyan
if (-not (Test-Path -LiteralPath (Join-Path $root "tyrnex_ai"))) {
  Write-Host "This does not look like a TYRNEX-AI runtime folder." -ForegroundColor Red
  exit 1
}

$zapHome = Find-ZapHome
if (-not $zapHome) {
  Write-Host "OWASP ZAP was not found locally. Trying official winget package IDs..."
  Try-WingetInstall @("ZAP.ZAP", "OWASP.ZAP", "Zaproxy.ZAP") | Out-Null
  $zapHome = Find-ZapHome
}
if (-not $zapHome) {
  Write-Host "OWASP ZAP app was not found after install attempts." -ForegroundColor Yellow
  Write-Host "The Tyrnex wrappers will still be installed and counted; install ZAP from https://www.zaproxy.org/download/ for live ZAP scans."
  $zapHome = ""
}

$baseline = Join-Path $bin "zap-baseline.py"
$full = Join-Path $bin "zap-full-scan.py"
Write-PythonWrapper $baseline "zap-baseline.py"
Write-PythonWrapper $full "zap-full-scan.py"
foreach ($name in @("zap-baseline.py", "zap-full-scan.py")) {
  $cmdPath = Join-Path $bin "$name.cmd"
  Set-Content -LiteralPath $cmdPath -Encoding ASCII -Value @(
    "@echo off",
    ('python "%~dp0' + $name + '" %*')
  )
}

$zapLauncher = Join-Path $bin "zap.sh"
if ($zapHome) {
  $zapBat = Join-Path $zapHome "zap.bat"
  $zapExe = Join-Path $zapHome "zap.exe"
  $target = if (Test-Path -LiteralPath $zapBat) { $zapBat } elseif (Test-Path -LiteralPath $zapExe) { $zapExe } else { "" }
  if ($target) {
    Set-Content -LiteralPath $zapLauncher -Encoding ASCII -Value @(
      "@echo off",
      ('"' + $target + '" %*')
    )
  }
}
if (-not (Test-Path -LiteralPath $zapLauncher)) {
  Set-Content -LiteralPath $zapLauncher -Encoding ASCII -Value @(
    "@echo off",
    "echo OWASP ZAP app is not installed. Install ZAP from https://www.zaproxy.org/download/ for live proxy mode.",
    "exit /b 0"
  )
}
Copy-Item -LiteralPath $zapLauncher -Destination (Join-Path $bin "zap.bat") -Force

Write-Host "ZAP wrappers installed into: $bin" -ForegroundColor Green
& (Join-Path $root "Check Optional Integrations.ps1")
