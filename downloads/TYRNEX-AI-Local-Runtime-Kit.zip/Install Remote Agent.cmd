@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install Remote Agent.ps1" %*
set "TYRNEX_INSTALL_EXIT=%ERRORLEVEL%"
echo.
if not "%TYRNEX_INSTALL_EXIT%"=="0" echo Installer stopped with exit code %TYRNEX_INSTALL_EXIT%.
pause
