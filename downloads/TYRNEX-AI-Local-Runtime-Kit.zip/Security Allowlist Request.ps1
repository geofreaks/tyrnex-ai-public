param(
  [string]$OutDir = ""
)

$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $OutDir) {
  $OutDir = Join-Path $root "data\compatibility"
}
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$stamp = Get-Date -Format "yyyyMMddTHHmmss"
$mdReport = Join-Path $OutDir "security-allowlist-request-$stamp.md"
$jsonReport = Join-Path $OutDir "security-allowlist-request-$stamp.json"
$csvReport = Join-Path $OutDir "security-allowlist-request-$stamp.csv"

function Test-PythonRuntime {
  param([string]$Path)
  if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return $false }
  try {
    & $Path -c "import sys; print(sys.version)" *> $null
    return $LASTEXITCODE -eq 0
  } catch {
    return $false
  }
}

function Resolve-TyrnexPython {
  $candidate = Join-Path $root ".venv\Scripts\python.exe"
  if (Test-PythonRuntime $candidate) { return $candidate }
  $runtime = Join-Path $root ".runtime\python\python.exe"
  if (Test-PythonRuntime $runtime) { return $runtime }
  $cmd = Get-Command python -ErrorAction SilentlyContinue
  if ($cmd -and (Test-PythonRuntime $cmd.Source)) { return $cmd.Source }
  return $null
}

function Get-ZoneIdentifier {
  param([string]$Path)
  try {
    $stream = Get-Item -LiteralPath $Path -Stream Zone.Identifier -ErrorAction SilentlyContinue
    if ($stream) { return "present" }
  } catch {}
  return "none"
}

function Get-SafeHash {
  param([string]$Path)
  if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return "" }
  try {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
  } catch {
    return ""
  }
}

Write-Host "TYRNEX-AI Security Allowlist Request" -ForegroundColor Cyan
Write-Host "Read-only report builder. This does not disable AV, EDR, XDR, Defender, firewall, services, or exclusions."
Write-Host ""

$python = Resolve-TyrnexPython
if (-not $python) {
  Write-Host "No usable TYRNEX Python runtime found. Run Run This First.cmd first." -ForegroundColor Red
  exit 1
}

$env:PYTHONPATH = "$root;$env:PYTHONPATH"
$code = "import json; from tyrnex_ai.setup_check import setup_items, is_kapefiles_ready_item; [print(json.dumps(dict(tool=i.tool, available=i.available, optional=i.optional, bundled=i.bundled, path=i.path, purpose=i.purpose, install_hint=i.install_hint, kapefiles_ready=is_kapefiles_ready_item(i)))) for i in setup_items()]"
$items = @()
try {
  $jsonLines = @(& $python -c $code)
  foreach ($line in $jsonLines) {
    if (-not [string]::IsNullOrWhiteSpace($line)) {
      $items += ($line | ConvertFrom-Json)
    }
  }
} catch {
  Write-Host "Could not enumerate TYRNEX tools: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}

$rows = New-Object System.Collections.Generic.List[object]
foreach ($item in $items) {
  $path = [string]$item.path
  $exists = $path -and (Test-Path -LiteralPath $path)
  $rows.Add([pscustomobject]@{
    tool = [string]$item.tool
    available = [bool]$item.available
    optional = [bool]$item.optional
    bundled = [bool]$item.bundled
    path = $path
    exists = [bool]$exists
    sha256 = if ($exists) { Get-SafeHash $path } else { "" }
    motw = if ($exists) { Get-ZoneIdentifier $path } else { "n/a" }
    purpose = [string]$item.purpose
    install_hint = [string]$item.install_hint
  }) | Out-Null
}

$detections = @()
try {
  $detections = @(Get-MpThreatDetection -ErrorAction Stop | Where-Object { $_.Resources -match [regex]::Escape($root) } | Select-Object -First 50)
} catch {}

$deviceGuard = ""
try {
  $dg = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard -ErrorAction Stop
  $deviceGuard = "SecurityServicesRunning=$($dg.SecurityServicesRunning -join ','); CodeIntegrityPolicyEnforcementStatus=$($dg.CodeIntegrityPolicyEnforcementStatus)"
} catch {
  $deviceGuard = "Unavailable: $($_.Exception.Message)"
}

$appLocker = ""
try {
  $policies = Get-AppLockerPolicy -Effective -ErrorAction Stop
  $appLocker = "Effective AppLocker policy readable; rule collections=$(@($policies.RuleCollections).Count)"
} catch {
  $appLocker = "Unavailable or not configured: $($_.Exception.Message)"
}

$payload = [pscustomobject]@{
  generated_at = (Get-Date).ToString("o")
  root = $root
  purpose = "Request approval for TYRNEX-AI security assessment and DFIR tools through normal security administration workflows."
  safety = "Read-only. Does not disable AV, EDR, XDR, Defender, firewall, services, or exclusions."
  reports = [pscustomobject]@{
    markdown = $mdReport
    json = $jsonReport
    csv = $csvReport
  }
  device_guard = $deviceGuard
  app_locker = $appLocker
  defender_detection_count = @($detections).Count
  tools = [object[]]$rows.ToArray()
}

$rows | Export-Csv -LiteralPath $csvReport -NoTypeInformation -Encoding UTF8
$payload | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jsonReport -Encoding UTF8

$lines = New-Object System.Collections.Generic.List[string]
$lines.Add("# TYRNEX-AI Security Allowlist Request") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("Generated: $(Get-Date)") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("This report is for security/admin review. It does not disable antivirus, EDR/XDR, Microsoft Defender, firewall, services, policies, or exclusions.") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("## Requested Scope") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("- Root: ``$root``") | Out-Null
$lines.Add("- Request: allow approved TYRNEX-AI assessment and DFIR binaries to run from this folder after hash/path review.") | Out-Null
$lines.Add("- Recommended handling: prefer publisher/hash/path allow rules in the security platform; do not globally disable endpoint protection.") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("## Local Security Signals") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("- WDAC / Device Guard: $deviceGuard") | Out-Null
$lines.Add("- AppLocker: $appLocker") | Out-Null
$lines.Add("- Defender detections referencing this folder: $(@($detections).Count)") | Out-Null
$lines.Add("") | Out-Null
if (@($detections).Count -gt 0) {
  $lines.Add("## Defender Detection References") | Out-Null
  $lines.Add("") | Out-Null
  foreach ($d in $detections) {
    $lines.Add("- $($d.ThreatName) · $($d.InitialDetectionTime) · $($d.Resources -join '; ')") | Out-Null
  }
  $lines.Add("") | Out-Null
}
$lines.Add("## Tool Inventory") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("| Tool | Available | Optional | Path | SHA256 | MOTW | Purpose |") | Out-Null
$lines.Add("| --- | --- | --- | --- | --- | --- | --- |") | Out-Null
foreach ($row in $rows | Sort-Object optional, tool) {
  $safePurpose = ($row.purpose -replace "\|", "/")
  $lines.Add("| ``$($row.tool)`` | $($row.available) | $($row.optional) | ``$($row.path)`` | ``$($row.sha256)`` | $($row.motw) | $safePurpose |") | Out-Null
}
$lines.Add("") | Out-Null
$lines.Add("## Administrator Notes") | Out-Null
$lines.Add("") | Out-Null
$lines.Add("- Approve only the exact reviewed TYRNEX folder, binaries, publishers, and/or SHA256 hashes needed for authorized assessment work.") | Out-Null
$lines.Add("- Prefer narrow allow rules over broad exclusions.") | Out-Null
$lines.Add("- Keep endpoint protection enabled and audit all executions.") | Out-Null
$lines.Add("- Re-run Security Compatibility Check after any approval to confirm the tool can launch.") | Out-Null

$lines | Set-Content -LiteralPath $mdReport -Encoding UTF8

$availableCount = @($rows | Where-Object { $_.available }).Count
$missingCount = @($rows | Where-Object { -not $_.available }).Count
$motwRows = @($rows | Where-Object { $_.motw -eq "present" })
$adminLikely = @($rows | Where-Object { $_.tool -in @("winpmem", "kape", "velociraptor", "msfconsole") })

Write-Host "Allowlist request reports created:" -ForegroundColor Green
Write-Host "  $mdReport"
Write-Host "  $jsonReport"
Write-Host "  $csvReport"
Write-Host ""
Write-Host "Screen summary" -ForegroundColor Cyan
Write-Host "  Root: $root"
Write-Host "  Tools inventoried: $($rows.Count); available=$availableCount; missing=$missingCount"
Write-Host "  Defender detections referencing TYRNEX: $(@($detections).Count)"
Write-Host "  WDAC / Device Guard: $deviceGuard"
Write-Host "  AppLocker: $appLocker"
if ($missingCount -gt 0) {
  Write-Host "  Missing tools to review:" -ForegroundColor Yellow
  foreach ($row in ($rows | Where-Object { -not $_.available } | Sort-Object optional, tool | Select-Object -First 12)) {
    Write-Host ("   - {0} optional={1}: {2}" -f $row.tool, $row.optional, $row.install_hint)
  }
}
if ($motwRows.Count -gt 0) {
  Write-Host "  Downloaded-file flag present:" -ForegroundColor Yellow
  foreach ($row in ($motwRows | Sort-Object tool | Select-Object -First 12)) {
    Write-Host ("   - {0}: {1}" -f $row.tool, $row.path)
  }
}
Write-Host "  Admin-sensitive tools included for narrow approval review:"
foreach ($row in ($adminLikely | Sort-Object tool)) {
  Write-Host ("   - {0}: {1}" -f $row.tool, $row.path)
}
Write-Host ""
Write-Host "Next: review these with your security/admin tooling. Do not globally disable endpoint protection." -ForegroundColor Yellow
