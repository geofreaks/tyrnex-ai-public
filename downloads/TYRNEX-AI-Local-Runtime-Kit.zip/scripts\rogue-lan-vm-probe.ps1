# TYRNEX-AI true LAN rogue-device probe using a Hyper-V external switch.
# Creates a tiny live Linux VM bridged to the selected physical adapter so the router can issue a real LAN DHCP lease.
param(
  [Parameter(Position = 0)]
  [ValidateSet("up", "status", "down", "remove", "adapters", "enable-hyperv")]
  [string]$Command = "status",

  [string]$AdapterName = "",
  [string]$VmName = "TYRNEX-AI-Rogue-LAN-Probe",
  [string]$SwitchName = "TYRNEX-AI-LAN-Probe-Switch",
  [string]$IsoUrl = "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/x86_64/alpine-virt-3.20.3-x86_64.iso",
  [switch]$NoElevate
)

$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $PSScriptRoot
$ProbeRoot = Join-Path $Root "data\rogue-lan-vm-probe"
$IsoPath = Join-Path $ProbeRoot "alpine-virt.iso"
$StatusPath = Join-Path $ProbeRoot "status.json"

function Test-IsAdmin {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Require-HyperV {
  $edition = ""
  try { $edition = (Get-ComputerInfo -Property WindowsEditionId).WindowsEditionId } catch {}
  if ($edition -in @("Core", "CoreSingleLanguage")) {
    throw "This is Windows Home ($edition). Full Hyper-V VM cmdlets are not supported here. Use the VirtualBox bridged LAN probe path instead."
  }
  if (-not (Get-Command Get-VM -ErrorAction SilentlyContinue)) {
    throw "Hyper-V PowerShell module is not available. Enable Hyper-V, reboot, then rerun this probe."
  }
}

function Enable-HyperVFeature {
  $edition = ""
  try { $edition = (Get-ComputerInfo -Property WindowsEditionId).WindowsEditionId } catch {}
  if ($edition -in @("Core", "CoreSingleLanguage")) {
    Write-Host "This machine is Windows Home ($edition)." -ForegroundColor Yellow
    Write-Host "Windows Home does not provide the full Hyper-V VM management stack needed for this probe." -ForegroundColor Yellow
    Write-Host "Use the VirtualBox bridged LAN probe option instead." -ForegroundColor Cyan
    Write-StatusJson ([ordered]@{
      tool = "tyrnex-ai-rogue-lan-vm-probe"
      mode = "hyperv-external-switch"
      vm_name = $VmName
      vm_exists = $false
      state = "unsupported-windows-home"
      switch = ""
      mac = ""
      ip_addresses = @()
      lan_visible_expected = $false
      status_path = $StatusPath
      note = "Windows Home does not include full Hyper-V VM management. Use the VirtualBox bridged LAN probe."
    })
    return
  }
  Write-Host "Enabling Hyper-V Windows feature. A reboot is required before the LAN VM probe can run." -ForegroundColor Yellow
  Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All -All -NoRestart
  Write-Host "Hyper-V enable requested. Reboot Windows, then run the probe again." -ForegroundColor Green
}

function Write-StatusJson($Data) {
  New-Item -ItemType Directory -Force -Path $ProbeRoot | Out-Null
  $copy = [ordered]@{}
  foreach ($key in $Data.Keys) {
    $copy[$key] = $Data[$key]
  }
  $copy.timestamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
  $copy | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $StatusPath -Encoding UTF8
}

function Get-PhysicalAdapters {
  Get-NetAdapter -Physical -ErrorAction SilentlyContinue |
    Where-Object {
      $_.Status -eq "Up" -and
      $_.Name -notmatch "vEthernet|Hyper-V|Loopback|TAP|VPN|Virtual|Npcap|Bluetooth"
    } |
    Sort-Object -Property LinkSpeed -Descending
}

function Select-ProbeAdapter {
  if ($AdapterName) {
    $adapter = Get-NetAdapter -Name $AdapterName -ErrorAction SilentlyContinue
    if (-not $adapter) { throw "Adapter '$AdapterName' was not found." }
    return $adapter
  }
  $adapters = @(Get-PhysicalAdapters)
  if ($adapters.Count -lt 1) {
    throw "No connected physical adapter found. Run: rogue-lan-vm-probe.ps1 adapters"
  }
  return $adapters[0]
}

function Ensure-ExternalSwitch([string]$Name, [string]$NetAdapterName) {
  $existing = Get-VMSwitch -Name $Name -ErrorAction SilentlyContinue
  if ($existing) { return $existing }
  Write-Host "Creating Hyper-V external switch '$Name' on adapter '$NetAdapterName'." -ForegroundColor Cyan
  Write-Host "This can briefly interrupt network connectivity while Windows bridges the adapter." -ForegroundColor Yellow
  New-VMSwitch -Name $Name -NetAdapterName $NetAdapterName -AllowManagementOS $true -Notes "TYRNEX-AI bridged rogue LAN probe" | Out-Null
  return Get-VMSwitch -Name $Name
}

function Ensure-Iso {
  New-Item -ItemType Directory -Force -Path $ProbeRoot | Out-Null
  if (Test-Path $IsoPath) { return }
  Write-Host "Downloading live Linux probe ISO..." -ForegroundColor Cyan
  Write-Host $IsoUrl -ForegroundColor DarkGray
  try {
    Invoke-WebRequest -Uri $IsoUrl -OutFile $IsoPath -UseBasicParsing
  } catch {
    Remove-Item -LiteralPath $IsoPath -Force -ErrorAction SilentlyContinue
    throw "Failed to download probe ISO: $($_.Exception.Message)"
  }
}

function Ensure-ProbeVm([string]$Name, [string]$Switch) {
  $vm = Get-VM -Name $Name -ErrorAction SilentlyContinue
  if (-not $vm) {
    Write-Host "Creating bridged probe VM '$Name'." -ForegroundColor Cyan
    New-VM -Name $Name -Generation 1 -MemoryStartupBytes 384MB -SwitchName $Switch -NoVHD | Out-Null
    Set-VM -Name $Name -AutomaticStartAction Nothing -AutomaticStopAction TurnOff | Out-Null
    Set-VMProcessor -VMName $Name -Count 1 | Out-Null
    Set-VMNetworkAdapter -VMName $Name -StaticMacAddress (New-ProbeMac) | Out-Null
  }
  $dvd = Get-VMDvdDrive -VMName $Name -ErrorAction SilentlyContinue
  if (-not $dvd) {
    Add-VMDvdDrive -VMName $Name -Path $IsoPath | Out-Null
  } else {
    Set-VMDvdDrive -VMName $Name -Path $IsoPath | Out-Null
  }
  Set-VMFirmwareCompat -VmName $Name
}

function New-ProbeMac {
  # Locally administered unicast MAC. Hyper-V expects 12 hex chars without separators.
  $bytes = New-Object byte[] 3
  [Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
  $suffix = (($bytes | ForEach-Object { $_.ToString("X2") }) -join "")
  return "02155D$suffix"
}

function Set-VMFirmwareCompat([string]$VmName) {
  # Generation 1 VMs boot ISO via BIOS. This function intentionally remains a no-op for portability.
  return
}

function Get-ProbeSnapshot {
  Require-HyperV
  $vm = Get-VM -Name $VmName -ErrorAction SilentlyContinue
  $adapter = $null
  if ($vm) { $adapter = Get-VMNetworkAdapter -VMName $VmName -ErrorAction SilentlyContinue }
  $ips = @()
  if ($adapter -and $adapter.IPAddresses) {
    $ips = @($adapter.IPAddresses | Where-Object { $_ -and $_ -notmatch "^fe80:" })
  }
  $switch = $null
  if ($adapter) { $switch = $adapter.SwitchName }
  return [ordered]@{
    tool = "tyrnex-ai-rogue-lan-vm-probe"
    mode = "hyperv-external-switch"
    vm_name = $VmName
    vm_exists = [bool]$vm
    state = if ($vm) { "$($vm.State)" } else { "missing" }
    switch = $switch
    mac = if ($adapter) { $adapter.MacAddress } else { "" }
    ip_addresses = $ips
    lan_visible_expected = [bool]($vm -and $adapter)
    status_path = $StatusPath
    note = "A running VM on an external Hyper-V switch should request a real LAN DHCP lease from your router. If IP is blank here, check your router DHCP/client list for the MAC."
  }
}

function Show-Status {
  try {
    $snap = Get-ProbeSnapshot
    Write-StatusJson $snap 2>$null
  } catch {
    $snap = [ordered]@{
      tool = "tyrnex-ai-rogue-lan-vm-probe"
      mode = "hyperv-external-switch"
      vm_name = $VmName
      vm_exists = $false
      state = "unavailable"
      switch = ""
      mac = ""
      ip_addresses = @()
      lan_visible_expected = $false
      status_path = $StatusPath
      note = $_.Exception.Message
    }
    Write-StatusJson $snap 2>$null
  }
  Write-Host ""
  Write-Host "TYRNEX-AI Hyper-V LAN Rogue Probe" -ForegroundColor Cyan
  Write-Host ("VM:      {0} ({1})" -f $snap.vm_name, $snap.state)
  Write-Host ("Switch:  {0}" -f $snap.switch)
  Write-Host ("MAC:     {0}" -f $snap.mac)
  $ipText = if ($snap.ip_addresses -and $snap.ip_addresses.Count) { ($snap.ip_addresses -join ", ") } else { "(not reported yet)" }
  Write-Host ("IP(s):   {0}" -f $ipText)
  Write-Host ("LAN:     {0}" -f ($(if ($snap.lan_visible_expected) { "bridged/external switch expected" } else { "not active" })))
  Write-Host ("Status:  {0}" -f $snap.status_path)
  Write-Host ("Note:    {0}" -f $snap.note) -ForegroundColor DarkYellow
}

if ($Command -in @("up", "down", "remove", "enable-hyperv") -and -not (Test-IsAdmin)) {
  if ($NoElevate) {
    Write-Host "Administrator rights are required for '$Command'." -ForegroundColor Red
    exit 1
  }
  $args = @("-NoExit", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"", $Command)
  if ($AdapterName) { $args += @("-AdapterName", "`"$AdapterName`"") }
  Start-Process -FilePath "powershell.exe" -ArgumentList $args -Verb RunAs
  exit 0
}

New-Item -ItemType Directory -Force -Path $ProbeRoot | Out-Null

switch ($Command) {
  "adapters" {
    $items = @(Get-PhysicalAdapters)
    if (-not $items.Count) {
      Write-Host "No connected physical adapters found." -ForegroundColor Yellow
      exit 0
    }
    $items | Select-Object Name, InterfaceDescription, Status, LinkSpeed, MacAddress | Format-Table -AutoSize
  }
  "enable-hyperv" {
    Enable-HyperVFeature
  }
  "up" {
    Require-HyperV
    $adapter = Select-ProbeAdapter
    Ensure-Iso
    Ensure-ExternalSwitch -Name $SwitchName -NetAdapterName $adapter.Name | Out-Null
    Ensure-ProbeVm -Name $VmName -Switch $SwitchName
    Start-VM -Name $VmName | Out-Null
    Write-Host "Started bridged LAN probe VM. Waiting for DHCP visibility..." -ForegroundColor Green
    Start-Sleep -Seconds 12
    Show-Status
  }
  "status" {
    Show-Status
  }
  "down" {
    Require-HyperV
    $vm = Get-VM -Name $VmName -ErrorAction SilentlyContinue
    if ($vm -and $vm.State -ne "Off") {
      Stop-VM -Name $VmName -TurnOff -Force
      Write-Host "Stopped probe VM." -ForegroundColor Green
    } else {
      Write-Host "Probe VM is not running." -ForegroundColor Yellow
    }
    Show-Status
  }
  "remove" {
    Require-HyperV
    $vm = Get-VM -Name $VmName -ErrorAction SilentlyContinue
    if ($vm) {
      if ($vm.State -ne "Off") { Stop-VM -Name $VmName -TurnOff -Force }
      Remove-VM -Name $VmName -Force
      Write-Host "Removed probe VM." -ForegroundColor Green
    }
    Write-Host "External switch '$SwitchName' was left in place to avoid interrupting host networking repeatedly." -ForegroundColor DarkYellow
  }
}
