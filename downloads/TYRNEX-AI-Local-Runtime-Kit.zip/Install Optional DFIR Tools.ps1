$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$python = Join-Path $root ".venv\Scripts\python.exe"
function Test-PythonRuntime {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { return $false }
  try {
    & $Path -c "import sys; print(sys.executable)" *> $null
    return $LASTEXITCODE -eq 0
  } catch {
    return $false
  }
}
if (-not (Test-PythonRuntime $python)) {
  Write-Host "Runtime is missing, broken, or was moved from another machine. Running first-run setup..." -ForegroundColor Yellow
  & (Join-Path $root "Run This First.ps1") -NoStart -SkipToolBootstrap
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
if (-not (Test-PythonRuntime $python)) {
  Write-Host "Runtime is not installed yet. Run 'Run This First.cmd' after installing Python 3.11+." -ForegroundColor Red
  exit 1
}
$env:PYTHONPATH = "$root;$env:PYTHONPATH"
Set-Location $root
Write-Host "TYRNEX-AI Optional DFIR Tools" -ForegroundColor Cyan
Write-Host "Installing/updating Eric Zimmerman tools supported by TYRNEX-AI..."
& $python -m tyrnex_ai.cli bootstrap-tools --tool eztools
if ($LASTEXITCODE -ne 0) {
  Write-Host "EZTools bootstrap reported an issue. Existing bundled tools may still be usable." -ForegroundColor Yellow
  $global:LASTEXITCODE = 0
}
Write-Host ""
Write-Host "Checking KAPE..."
& $python -m tyrnex_ai.cli bootstrap-tools --tool kape
if ($LASTEXITCODE -ne 0) {
  Write-Host "KAPE is optional/manual because the official Kroll download is gated." -ForegroundColor Yellow
  $global:LASTEXITCODE = 0
}
$kapeCandidates = @((Join-Path $root "tools\kape\kape.exe"), (Join-Path $root "tools\kape\gkape.exe"), (Join-Path $root "tools\kape\KAPE.exe"))
$kapeFound = $false
foreach ($candidate in $kapeCandidates) {
  if (Test-Path -LiteralPath $candidate) {
    $kapeFound = $true
    Write-Host "KAPE found: $candidate" -ForegroundColor Green
    break
  }
}
if (-not $kapeFound) {
  $kapeFiles = Join-Path $root "tools\kape\KapeFiles"
  if ((Test-Path -LiteralPath (Join-Path $kapeFiles "Targets")) -and (Test-Path -LiteralPath (Join-Path $kapeFiles "Modules"))) {
    Write-Host "KapeFiles targets/modules are ready: $kapeFiles" -ForegroundColor Green
  }
  Write-Host "KAPE executable not found. Download it from Kroll/SANS and place the extracted folder at:" -ForegroundColor Yellow
  Write-Host "  $root\tools\kape"
  Write-Host "TYRNEX-AI builtin disk triage works without KAPE; KAPE just enables the external collector path."
}
Write-Host ""
Write-Host "Current DFIR summary:"
$json = & $python -c "import json; from tyrnex_ai.setup_check import setup_items, is_kapefiles_ready_item; items=setup_items(); names=['winpmem','kape','chainsaw','volatility3','velociraptor','avml','EvtxECmd','PECmd','LECmd','JLECmd','RBCmd','MFTECmd','AmcacheParser','AppCompatCacheParser','SrumECmd','RECmd','hayabusa']; print(json.dumps([{'tool': i.tool, 'available': i.available, 'kapefiles_ready': is_kapefiles_ready_item(i)} for i in items if i.tool in names]))"
$items = $json | ConvertFrom-Json
foreach ($item in $items) {
  if ($item.tool -eq "kape" -and $item.kapefiles_ready) {
    Write-Host "  kape: KapeFiles ready; executable manual/gated" -ForegroundColor Yellow
  } elseif ($item.available) {
    Write-Host "  $($item.tool): ready" -ForegroundColor Green
  } else {
    Write-Host "  $($item.tool): optional/manual" -ForegroundColor Yellow
  }
}
Write-Host ""
Write-Host "Optional DFIR check complete." -ForegroundColor Green
