$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $root "Start TYRNEX-AI.cmd"
$icon = Join-Path $root "assets\tyrnex-ai-logo.ico"
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "TYRNEX-AI Dashboard.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $target
$shortcut.WorkingDirectory = $root
$shortcut.Description = "TYRNEX-AI protected local runtime"
if (Test-Path $icon) {
  $shortcut.IconLocation = $icon
}
$shortcut.Save()
Write-Host "Created shortcut: $shortcutPath"
