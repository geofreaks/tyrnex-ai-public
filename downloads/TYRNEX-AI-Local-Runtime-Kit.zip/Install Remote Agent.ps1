param(
  [string]$ControllerHost = "",
  [int]$Port = 9443,
  [int]$DashboardPort = 8765,
  [string]$Label = "",
  [switch]$NoStart,
  [switch]$ForceReenroll,
  [switch]$SkipMemoryHelper,
  [switch]$AddDefenderExclusions,
  [switch]$RemoveDefenderExclusions
)
$ErrorActionPreference = "Stop"
$InstallerVersion = "2026-09-29.1"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$bootstrapPath = Join-Path $root "agent-bootstrap.json"
$caPath = Join-Path $root "dashboard-ca.pem"
Write-Host "TYRNEX-AI Remote Agent Installer"
Write-Host "Installer version: $InstallerVersion"
Write-Host "Portable foreground agent. No service, hidden persistence, or firewall changes."
Write-Host "Endpoint protection changes are opt-in only: -AddDefenderExclusions adds narrow Microsoft Defender exclusions for this agent folder."
if ($AddDefenderExclusions -and $RemoveDefenderExclusions) { throw "Use either -AddDefenderExclusions or -RemoveDefenderExclusions, not both." }
if (-not (Test-Path -LiteralPath $bootstrapPath) -or -not (Test-Path -LiteralPath $caPath)) {
  Write-Host ""
  Write-Host "This generic installer is missing its enrollment package files." -ForegroundColor Yellow
  Write-Host ""
  Write-Host "Required files beside Install Remote Agent.cmd:"
  Write-Host "  - agent-bootstrap.json"
  Write-Host "  - dashboard-ca.pem"
  Write-Host ""
  Write-Host "Correct install flow:"
  Write-Host "  1. Open TYRNEX dashboard on the controller."
  Write-Host "  2. Go to Remote Devices."
  Write-Host "  3. Click Download agent installer."
  Write-Host "  4. Copy the downloaded TYRNEX-Agent-Installer.zip to this endpoint."
  Write-Host "  5. Extract the ZIP and run its Install Remote Agent.cmd."
  Write-Host ""
  Write-Host "The package is required because it contains a trusted dashboard CA and a short-lived one-device enrollment invitation."
  exit 2
}
$bootstrap = Get-Content -LiteralPath $bootstrapPath -Raw | ConvertFrom-Json
if ($bootstrap.schema_version -ne 1) { throw "Unsupported enrollment package." }
if (-not $bootstrap.agent_release) { throw "Enrollment package is missing its agent release identity. Download a fresh package from the dashboard." }
Write-Host "Agent release: $($bootstrap.agent_release)"
$dashboard = [Uri]$bootstrap.dashboard_url
$controller = [Uri]$bootstrap.controller_url
if (($PSBoundParameters.ContainsKey("Port") -and $Port -ne $controller.Port) -or ($PSBoundParameters.ContainsKey("DashboardPort") -and $DashboardPort -ne $dashboard.Port)) {
  throw "Port overrides differ from the trusted package. Download a package with the intended controller addresses."
}
foreach ($uri in @($dashboard, $controller)) {
  if ($uri.Scheme -ne "https" -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne "/") { throw "Invalid HTTPS origin in enrollment package." }
}
$curl = Get-Command curl.exe -ErrorAction Stop
# Private dashboard CAs do not publish revocation URLs. Keep chain/hostname
# verification; tolerate unavailable revocation data, never a revoked certificate.
$tlsOptions = @("--proto", "=https", "--tlsv1.2", "--cacert", $caPath, "--ssl-revoke-best-effort")
$dashboardUrl = $bootstrap.dashboard_url.TrimEnd("/")
$controllerUrl = $bootstrap.controller_url.TrimEnd("/")

function Resolve-ControllerHostInput {
  param([string]$Value)
  $text = $Value.Trim()
  if (-not $text) { return "" }
  if ($text -match '^https?://') {
    $uri = [Uri]$text
    if ($uri.UserInfo -or $uri.Query -or $uri.Fragment) { throw "Controller host override must not include credentials, query, or fragment." }
    if ($uri.Port -ne -1 -and $uri.Port -notin @($Port, $DashboardPort)) { throw "Controller host override used unexpected port $($uri.Port)." }
    return $uri.Host
  }
  if ($text.Contains("/")) { throw "Controller host override must be a hostname or IP only." }
  if ($text -match '^\[[^\]]+\](:\d+)?$') {
    $uri = [Uri]("https://" + $text)
    if ($uri.Port -ne -1 -and $uri.Port -notin @($Port, $DashboardPort)) { throw "Controller host override used unexpected port $($uri.Port)." }
    return $uri.Host
  }
  if ($text -match '^[^:]+:\d+$') {
    $uri = [Uri]("https://" + $text)
    if ($uri.Port -notin @($Port, $DashboardPort)) { throw "Controller host override used unexpected port $($uri.Port)." }
    return $uri.Host
  }
  return $text
}

function Set-ControllerEndpointHost {
  param([string]$HostName)
  $script:dashboardUrl = "https://${HostName}:$DashboardPort"
  $script:controllerUrl = "https://${HostName}:$Port"
}

function Test-ControllerDashboardReachable {
  param([string]$Url)
  $statusPath = Join-Path $env:TEMP ("tyrnex-agent-status-probe-" + [Guid]::NewGuid().ToString("N") + ".json")
  try {
    & $curl.Source @tlsOptions @("--fail", "--silent", "--show-error", "--max-time", "10", "--output", $statusPath, ($Url.TrimEnd("/") + "/api/agent/status")) | Out-Null
    return ($LASTEXITCODE -eq 0)
  } catch {
    return $false
  } finally {
    if (Test-Path -LiteralPath $statusPath) { Remove-Item -LiteralPath $statusPath -Force }
  }
}

$controllerOverride = $ControllerHost
if (-not $controllerOverride -and $env:TYRNEX_AGENT_CONTROLLER_HOST) { $controllerOverride = $env:TYRNEX_AGENT_CONTROLLER_HOST }
if ($controllerOverride) {
  $overrideHost = Resolve-ControllerHostInput -Value $controllerOverride
  if ($overrideHost) {
    Set-ControllerEndpointHost -HostName $overrideHost
    Write-Host "Using controller host override: $overrideHost"
  }
} elseif (-not (Test-ControllerDashboardReachable -Url $dashboardUrl)) {
  Write-Warning "The packaged controller dashboard is not reachable at $dashboardUrl."
  Write-Host "If the controller LAN IP changed, enter the new controller host/IP now."
  Write-Host "Leave blank to keep the packaged address. If the controller identity/certificate was reset, download a fresh package instead."
  $answer = Read-Host "New controller host/IP"
  if ($answer) {
    $overrideHost = Resolve-ControllerHostInput -Value $answer
    if ($overrideHost) {
      Set-ControllerEndpointHost -HostName $overrideHost
      Write-Host "Trying updated controller host: $overrideHost"
    }
  }
}

if (-not $Label) { $Label = $env:COMPUTERNAME }
$agentDir = Join-Path $root "agent"
$stateDir = Join-Path $agentDir "agent-state"
New-Item -ItemType Directory -Path $agentDir -Force | Out-Null

function Write-Utf8NoBomFile {
  param([string]$Path, [string]$Content)
  [IO.File]::WriteAllText($Path, $Content, (New-Object Text.UTF8Encoding($false)))
}

function Test-PinnedFile {
  param([string]$Path, [string]$Expected)
  if ($Expected -notmatch '^[a-fA-F0-9]{64}$') { throw "Missing trusted artifact SHA-256." }
  if (-not (Test-Path -LiteralPath $Path)) { return $false }
  $stream = [IO.File]::OpenRead($Path)
  $hasher = [Security.Cryptography.SHA256]::Create()
  try { return [BitConverter]::ToString($hasher.ComputeHash($stream)).Replace("-", "") -eq $Expected }
  finally { $hasher.Dispose(); $stream.Dispose() }
}

function Get-Sha256 {
  param([string]$Path)
  if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return "" }
  return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Write-AllowlistManifest {
  param([string]$AgentPath, [string]$AgentHash, [string]$AgentReleaseValue, [string]$HelperPath)
  $items = @(
    [pscustomobject]@{role="remote-agent"; path=$AgentPath; sha256=$AgentHash}
  )
  if ($HelperPath -and (Test-Path -LiteralPath $HelperPath)) {
    $items += [pscustomobject]@{role="memory-helper"; path=$HelperPath; sha256=(Get-Sha256 -Path $HelperPath)}
  }
  $manifest = [pscustomobject]@{
    schema_version = 1
    generated_utc = [DateTimeOffset]::UtcNow.ToString("o")
    installer_version = $InstallerVersion
    agent_release = $AgentReleaseValue
    controller = $controllerUrl
    agent_dir = [IO.Path]::GetFullPath($agentDir)
    state_dir = [IO.Path]::GetFullPath($stateDir)
    files = $items
    recommended_allowlist = [pscustomobject]@{
      paths = @([IO.Path]::GetFullPath($agentDir))
      processes = @($AgentPath) + @($HelperPath | Where-Object { $_ -and (Test-Path -LiteralPath $_) })
      notes = @(
        "Allowlist only for owned/authorized TYRNEX incident-response endpoints.",
        "Do not disable realtime protection, firewall, SmartScreen, EDR/XDR, or Windows services.",
        "Use the SHA-256 values above in third-party AV/EDR consoles when path allowlisting is not enough."
      )
    }
  }
  $allowlistPath = Join-Path $root "agent-allowlist.json"
  Write-Utf8NoBomFile -Path $allowlistPath -Content ($manifest | ConvertTo-Json -Depth 6)
  Write-Host "EDR/AV allowlist manifest written: $allowlistPath"
  return $allowlistPath
}

function Update-DefenderExclusions {
  param([string]$AgentPath, [string]$HelperPath, [switch]$Remove)
  $paths = @([IO.Path]::GetFullPath($agentDir)) | Select-Object -Unique
  $processes = @($AgentPath) + @($HelperPath | Where-Object { $_ -and (Test-Path -LiteralPath $_) })
  $processes = @($processes | Where-Object { $_ } | Select-Object -Unique)
  try {
    if ($Remove) {
      $cmd = Get-Command Remove-MpPreference -ErrorAction Stop
      foreach ($path in $paths) { & $cmd.Source -ExclusionPath $path -ErrorAction SilentlyContinue; Write-Host "Removed Defender ExclusionPath: $path" }
      foreach ($proc in $processes) { & $cmd.Source -ExclusionProcess $proc -ErrorAction SilentlyContinue; Write-Host "Removed Defender ExclusionProcess: $proc" }
    } else {
      $cmd = Get-Command Add-MpPreference -ErrorAction Stop
      foreach ($path in $paths) { & $cmd.Source -ExclusionPath $path -ErrorAction Stop; Write-Host "Added Defender ExclusionPath: $path" }
      foreach ($proc in $processes) { & $cmd.Source -ExclusionProcess $proc -ErrorAction Stop; Write-Host "Added Defender ExclusionProcess: $proc" }
    }
  } catch {
    Write-Warning "Defender exclusion update was not applied: $($_.Exception.Message)"
  }
}

function Get-ControllerAgentRelease {
  $statusPath = Join-Path $env:TEMP ("tyrnex-agent-status-" + [Guid]::NewGuid().ToString("N") + ".json")
  try {
    $url = $dashboardUrl + "/api/agent/status"
    Write-Host "Checking controller for latest agent release: $url"
    & $curl.Source @tlsOptions @("--fail", "--silent", "--show-error", "--max-time", "30", "--output", $statusPath, $url)
    if ($LASTEXITCODE -ne 0) { throw "agent status request failed" }
    $status = Get-Content -LiteralPath $statusPath -Raw | ConvertFrom-Json
    if (-not $status.available -or -not $status.sha256 -or -not $status.release) { throw "agent status did not include release metadata" }
    if ($status.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw "agent status returned an invalid SHA-256" }
    if ($status.download -ne "/api/agent/download") { throw "agent status returned an unexpected download route" }
    return [pscustomobject]@{release=[string]$status.release; sha256=([string]$status.sha256).ToLowerInvariant(); route=[string]$status.download; source="controller"}
  } catch {
    Write-Warning "Could not check latest controller agent release; using package-pinned agent release $($bootstrap.agent_release): $($_.Exception.Message)"
    return [pscustomobject]@{release=[string]$bootstrap.agent_release; sha256=([string]$bootstrap.agent_sha256).ToLowerInvariant(); route="/api/agent/download"; source="package"}
  } finally {
    if (Test-Path -LiteralPath $statusPath) { Remove-Item -LiteralPath $statusPath -Force }
  }
}

function Stop-AgentUsingPath {
  param([string]$Path, [string]$StatePath = "")
  $full = [IO.Path]::GetFullPath($Path)
  $stateFull = if ($StatePath) { [IO.Path]::GetFullPath($StatePath) } else { "" }
  try {
    $matches = @(Get-CimInstance Win32_Process -Filter "Name='tyrnex-agent.exe'" | Where-Object {
      $exeMatch = $false
      $stateMatch = $false
      if ($_.ExecutablePath) {
        try { $exeMatch = [IO.Path]::GetFullPath($_.ExecutablePath) -eq $full } catch {}
      }
      if ($stateFull -and $_.CommandLine) {
        $stateMatch = $_.CommandLine.IndexOf($stateFull, [StringComparison]::OrdinalIgnoreCase) -ge 0
      }
      $exeMatch -or $stateMatch
    })
    foreach ($proc in $matches) {
      Write-Host "Stopping existing foreground agent for update: PID $($proc.ProcessId)"
      Stop-Process -Id ([int]$proc.ProcessId) -Force -ErrorAction Stop
    }
  } catch {
    Write-Warning "Could not stop an existing agent process automatically: $($_.Exception.Message)"
  }
}

function Get-VerifiedArtifact {
  param([string]$Route, [string]$Target, [string]$Expected)
  if (Test-PinnedFile -Path $Target -Expected $Expected) { return $Target }
  $temporary = "$Target.download-$([Guid]::NewGuid().ToString('N'))"
  try {
    $url = $dashboardUrl + $Route
    Write-Host "Downloading verified artifact: $url"
    & $curl.Source @tlsOptions @("--fail", "--silent", "--show-error", "--max-time", "120", "--output", $temporary, $url)
    if ($LASTEXITCODE -ne 0) { throw "HTTPS download failed. Check controller reachability, certificate hostname/trust, and package freshness." }
    if (-not (Test-PinnedFile -Path $temporary -Expected $Expected)) { throw "Artifact hash mismatch. Nothing downloaded will be executed; obtain a fresh package after controller upgrades." }
    Stop-AgentUsingPath -Path $Target -StatePath $stateDir
    [IO.File]::Copy($temporary, $Target, $true)
    return $Target
  } finally {
    if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
  }
}

$agentRelease = Get-ControllerAgentRelease
if ($agentRelease.release -ne $bootstrap.agent_release) {
  Write-Host "Controller has newer agent release: $($agentRelease.release) (package pinned $($bootstrap.agent_release))"
}
$agentExe = Get-VerifiedArtifact -Route $agentRelease.route -Target (Join-Path $agentDir "tyrnex-agent.exe") -Expected $agentRelease.sha256
Write-Host "Verified agent release: $($agentRelease.release) [$($agentRelease.source)]"
Write-Host "Verified agent SHA-256: $($agentRelease.sha256)"
if ($ForceReenroll -and (Test-Path -LiteralPath $stateDir)) {
  $source = [IO.Path]::GetFullPath($stateDir)
  $parent = [IO.Path]::GetFullPath($agentDir).TrimEnd('\') + '\'
  $archive = $source + ".retired-" + [Guid]::NewGuid().ToString("N")
  if (-not $source.StartsWith($parent, [StringComparison]::OrdinalIgnoreCase) -or -not $archive.StartsWith($parent, [StringComparison]::OrdinalIgnoreCase)) { throw "Agent state archive is outside the installer directory." }
  Move-Item -LiteralPath $source -Destination $archive
  Write-Host "Prior identity retained at $archive"
}
$cfgPath = Join-Path $stateDir "agent.json"
$identity = Join-Path $stateDir "identity.dpapi"
$device = Join-Path $stateDir "device.pem"
$ca = Join-Path $stateDir "ca.pem"
if (-not (Test-Path -LiteralPath $identity)) {
  & $agentExe --state $stateDir --init $controllerUrl
  if ($LASTEXITCODE -ne 0) { throw "Agent identity creation failed." }
}
$cfg = Get-Content -LiteralPath $cfgPath -Raw | ConvertFrom-Json
if ($cfg.url -ne $controllerUrl) {
  if ($cfg.url -eq $bootstrap.controller_url -and $controllerUrl -ne $bootstrap.controller_url) {
    $cfg.url = $controllerUrl
    Write-Utf8NoBomFile -Path $cfgPath -Content ($cfg | ConvertTo-Json -Depth 5)
    Write-Host "Updated saved controller URL to $controllerUrl"
  } else {
    throw "Existing agent identity belongs to another controller. Use a separate directory or explicit -ForceReenroll."
  }
}
if (-not (Test-Path -LiteralPath $device) -or -not (Test-Path -LiteralPath $ca)) {
  if ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() -ge [double]$bootstrap.expires) { throw "Enrollment package expired. Download a fresh package from the dashboard." }
  $request = [IO.File]::ReadAllText((Join-Path $stateDir "request.pem")).Trim()
  if ($request -notmatch "-----BEGIN CERTIFICATE REQUEST-----" -or $request.Length -lt 100) { throw "Local CSR is missing or invalid." }
  $bodyPath = Join-Path $stateDir "enroll-request.json"
  $replyPath = Join-Path $stateDir "enroll-reply.json"
  try {
    Write-Utf8NoBomFile -Path $bodyPath -Content (@{csr=$request; label=$Label; invitation=$bootstrap.invitation} | ConvertTo-Json -Depth 3)
    & $curl.Source @tlsOptions @("--fail", "--silent", "--show-error", "--max-time", "120", "--header", "Content-Type: application/json", "--data-binary", "@$bodyPath", "--output", $replyPath, ($dashboardUrl + "/api/agent/enroll"))
    if ($LASTEXITCODE -ne 0) { throw "Enrollment failed. Check package expiry and controller logs. HTTP fallback and untrusted TLS are not permitted." }
    $reply = Get-Content -LiteralPath $replyPath -Raw | ConvertFrom-Json
    if (-not $reply.device_pem -or -not $reply.ca_pem) { throw "Enrollment response did not include certificates." }
    Write-Utf8NoBomFile -Path $device -Content $reply.device_pem
    Write-Utf8NoBomFile -Path $ca -Content $reply.ca_pem
    Write-Host "Enrollment complete. Device id: $($reply.device)"
    if ($reply.listener_warning) { Write-Warning $reply.listener_warning }
  } finally {
    foreach ($path in @($bodyPath, $replyPath)) { if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force } }
  }
} else { Write-Host "Existing enrolled identity retained." }

$memoryHelper = ""
if (-not $SkipMemoryHelper -and $bootstrap.winpmem_sha256) {
  try {
    $helper = Get-VerifiedArtifact -Route "/api/agent/winpmem" -Target (Join-Path $agentDir "winpmem.exe") -Expected $bootstrap.winpmem_sha256
    $memoryHelper = $helper
    $cfg | Add-Member -NotePropertyName winpmem -NotePropertyValue $helper -Force
    $cfg | Add-Member -NotePropertyName winpmem_sha256 -NotePropertyValue $bootstrap.winpmem_sha256 -Force
    $cfg | Add-Member -NotePropertyName allow_memory -NotePropertyValue $true -Force
    $budget = [int64](128GB)
    try { $budget = [Math]::Min([int64](128GB), [int64](Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory + [int64](8GB)) } catch {}
    $cfg | Add-Member -NotePropertyName memory_max_bytes -NotePropertyValue $budget -Force
    Write-Utf8NoBomFile -Path $cfgPath -Content ($cfg | ConvertTo-Json -Depth 5)
    Write-Host "Memory helper verified. Memory capture requires Administrator and sufficient disk space."
  } catch { Write-Warning "Optional memory helper was not provisioned: $($_.Exception.Message)" }
}
$allowlistManifest = Write-AllowlistManifest -AgentPath $agentExe -AgentHash $agentRelease.sha256 -AgentReleaseValue $agentRelease.release -HelperPath $memoryHelper
if ($AddDefenderExclusions) {
  Update-DefenderExclusions -AgentPath $agentExe -HelperPath $memoryHelper
} elseif ($RemoveDefenderExclusions) {
  Update-DefenderExclusions -AgentPath $agentExe -HelperPath $memoryHelper -Remove
}
Write-Host "Agent: $agentExe"
Write-Host "State: $stateDir"
Write-Host "Controller: $controllerUrl"
Write-Host "Allowlist manifest: $allowlistManifest"
Write-Host "Enrollment is complete; an online heartbeat confirms connectivity."
if (-not $NoStart) {
  Write-Host "Starting foreground agent. Ctrl+C stops it."
  & $agentExe --state $stateDir
  if ($LASTEXITCODE -ne 0) { throw "Agent exited with an error. Review the output above." }
}
