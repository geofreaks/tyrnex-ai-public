param(
  [string]$ControllerHost = "",
  [int]$Port = 9443,
  [int]$DashboardPort = 8765,
  [string]$Label = "",
  [switch]$NoStart,
  [switch]$ForceReenroll,
  [switch]$SkipMemoryHelper
)
$ErrorActionPreference = "Stop"
$InstallerVersion = "2026-09-24.3"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$bootstrapPath = Join-Path $root "agent-bootstrap.json"
$caPath = Join-Path $root "dashboard-ca.pem"
Write-Host "TYRNEX-AI Remote Agent Installer"
Write-Host "Installer version: $InstallerVersion"
Write-Host "Portable foreground agent. No service, hidden persistence, firewall exclusion, or endpoint protection changes."
if (-not (Test-Path -LiteralPath $bootstrapPath) -or -not (Test-Path -LiteralPath $caPath)) {
  Write-Host ""
  Write-Host "This generic installer is missing its enrollment package files." -ForegroundColor Yellow
  Write-Host ""
  Write-Host "Required files beside Install Remote Agent.cmd:"
  Write-Host "  - agent-bootstrap.json"
  Write-Host "  - dashboard-ca.pem"
  Write-Host ""
  Write-Host "Correct install flow:"
  Write-Host "  1. Open TYRNEX dashboard on the controller."
  Write-Host "  2. Go to Remote Devices."
  Write-Host "  3. Click Download agent installer."
  Write-Host "  4. Copy the downloaded TYRNEX-Agent-Installer.zip to this endpoint."
  Write-Host "  5. Extract the ZIP and run its Install Remote Agent.cmd."
  Write-Host ""
  Write-Host "The package is required because it contains a trusted dashboard CA and a short-lived one-device enrollment invitation."
  exit 2
}
$bootstrap = Get-Content -LiteralPath $bootstrapPath -Raw | ConvertFrom-Json
if ($bootstrap.schema_version -ne 1) { throw "Unsupported enrollment package." }
$dashboard = [Uri]$bootstrap.dashboard_url
$controller = [Uri]$bootstrap.controller_url
if (($PSBoundParameters.ContainsKey("Port") -and $Port -ne $controller.Port) -or ($PSBoundParameters.ContainsKey("DashboardPort") -and $DashboardPort -ne $dashboard.Port)) {
  throw "Port overrides differ from the trusted package. Download a package with the intended controller addresses."
}
foreach ($uri in @($dashboard, $controller)) {
  if ($uri.Scheme -ne "https" -or $uri.UserInfo -or $uri.Query -or $uri.Fragment -or $uri.AbsolutePath -ne "/") { throw "Invalid HTTPS origin in enrollment package." }
}
if ($ControllerHost -and $ControllerHost -ne $controller.Host -and $ControllerHost.TrimEnd("/") -ne $bootstrap.controller_url) {
  throw "Controller differs from the trusted enrollment package. Download a package from the intended controller."
}
$curl = Get-Command curl.exe -ErrorAction Stop
# Private dashboard CAs do not publish revocation URLs. Keep chain/hostname
# verification; tolerate unavailable revocation data, never a revoked certificate.
$tlsOptions = @("--proto", "=https", "--tlsv1.2", "--cacert", $caPath, "--ssl-revoke-best-effort")
if (-not $Label) { $Label = $env:COMPUTERNAME }
$agentDir = Join-Path $root "agent"
$stateDir = Join-Path $agentDir "agent-state"
New-Item -ItemType Directory -Path $agentDir -Force | Out-Null

function Write-Utf8NoBomFile {
  param([string]$Path, [string]$Content)
  [IO.File]::WriteAllText($Path, $Content, (New-Object Text.UTF8Encoding($false)))
}

function Test-PinnedFile {
  param([string]$Path, [string]$Expected)
  if ($Expected -notmatch '^[a-fA-F0-9]{64}$') { throw "Missing trusted artifact SHA-256." }
  if (-not (Test-Path -LiteralPath $Path)) { return $false }
  $stream = [IO.File]::OpenRead($Path)
  $hasher = [Security.Cryptography.SHA256]::Create()
  try { return [BitConverter]::ToString($hasher.ComputeHash($stream)).Replace("-", "") -eq $Expected }
  finally { $hasher.Dispose(); $stream.Dispose() }
}

function Get-VerifiedArtifact {
  param([string]$Route, [string]$Target, [string]$Expected)
  if (Test-PinnedFile -Path $Target -Expected $Expected) { return $Target }
  $temporary = "$Target.download-$([Guid]::NewGuid().ToString('N'))"
  try {
    $url = $bootstrap.dashboard_url + $Route
    Write-Host "Downloading verified artifact: $url"
    & $curl.Source @tlsOptions @("--fail", "--silent", "--show-error", "--max-time", "120", "--output", $temporary, $url)
    if ($LASTEXITCODE -ne 0) { throw "HTTPS download failed. Check controller reachability, certificate hostname/trust, and package freshness." }
    if (-not (Test-PinnedFile -Path $temporary -Expected $Expected)) { throw "Artifact hash mismatch. Nothing downloaded will be executed; obtain a fresh package after controller upgrades." }
    [IO.File]::Copy($temporary, $Target, $true)
    return $Target
  } finally {
    if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force }
  }
}

$agentExe = Get-VerifiedArtifact -Route "/api/agent/download" -Target (Join-Path $agentDir "tyrnex-agent.exe") -Expected $bootstrap.agent_sha256
Write-Host "Verified agent SHA-256: $($bootstrap.agent_sha256)"
if ($ForceReenroll -and (Test-Path -LiteralPath $stateDir)) {
  $source = [IO.Path]::GetFullPath($stateDir)
  $parent = [IO.Path]::GetFullPath($agentDir).TrimEnd('\') + '\'
  $archive = $source + ".retired-" + [Guid]::NewGuid().ToString("N")
  if (-not $source.StartsWith($parent, [StringComparison]::OrdinalIgnoreCase) -or -not $archive.StartsWith($parent, [StringComparison]::OrdinalIgnoreCase)) { throw "Agent state archive is outside the installer directory." }
  Move-Item -LiteralPath $source -Destination $archive
  Write-Host "Prior identity retained at $archive"
}
$cfgPath = Join-Path $stateDir "agent.json"
$identity = Join-Path $stateDir "identity.dpapi"
$device = Join-Path $stateDir "device.pem"
$ca = Join-Path $stateDir "ca.pem"
if (-not (Test-Path -LiteralPath $identity)) {
  & $agentExe --state $stateDir --init $bootstrap.controller_url
  if ($LASTEXITCODE -ne 0) { throw "Agent identity creation failed." }
}
$cfg = Get-Content -LiteralPath $cfgPath -Raw | ConvertFrom-Json
if ($cfg.url -ne $bootstrap.controller_url) { throw "Existing agent identity belongs to another controller. Use a separate directory or explicit -ForceReenroll." }
if (-not (Test-Path -LiteralPath $device) -or -not (Test-Path -LiteralPath $ca)) {
  if ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds() -ge [double]$bootstrap.expires) { throw "Enrollment package expired. Download a fresh package from the dashboard." }
  $request = [IO.File]::ReadAllText((Join-Path $stateDir "request.pem")).Trim()
  if ($request -notmatch "-----BEGIN CERTIFICATE REQUEST-----" -or $request.Length -lt 100) { throw "Local CSR is missing or invalid." }
  $bodyPath = Join-Path $stateDir "enroll-request.json"
  $replyPath = Join-Path $stateDir "enroll-reply.json"
  try {
    Write-Utf8NoBomFile -Path $bodyPath -Content (@{csr=$request; label=$Label; invitation=$bootstrap.invitation} | ConvertTo-Json -Depth 3)
    & $curl.Source @tlsOptions @("--fail", "--silent", "--show-error", "--max-time", "120", "--header", "Content-Type: application/json", "--data-binary", "@$bodyPath", "--output", $replyPath, ($bootstrap.dashboard_url + "/api/agent/enroll"))
    if ($LASTEXITCODE -ne 0) { throw "Enrollment failed. Check package expiry and controller logs. HTTP fallback and untrusted TLS are not permitted." }
    $reply = Get-Content -LiteralPath $replyPath -Raw | ConvertFrom-Json
    if (-not $reply.device_pem -or -not $reply.ca_pem) { throw "Enrollment response did not include certificates." }
    Write-Utf8NoBomFile -Path $device -Content $reply.device_pem
    Write-Utf8NoBomFile -Path $ca -Content $reply.ca_pem
    Write-Host "Enrollment complete. Device id: $($reply.device)"
    if ($reply.listener_warning) { Write-Warning $reply.listener_warning }
  } finally {
    foreach ($path in @($bodyPath, $replyPath)) { if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force } }
  }
} else { Write-Host "Existing enrolled identity retained." }

if (-not $SkipMemoryHelper -and $bootstrap.winpmem_sha256) {
  try {
    $helper = Get-VerifiedArtifact -Route "/api/agent/winpmem" -Target (Join-Path $agentDir "winpmem.exe") -Expected $bootstrap.winpmem_sha256
    $cfg | Add-Member -NotePropertyName winpmem -NotePropertyValue $helper -Force
    $cfg | Add-Member -NotePropertyName winpmem_sha256 -NotePropertyValue $bootstrap.winpmem_sha256 -Force
    $cfg | Add-Member -NotePropertyName allow_memory -NotePropertyValue $true -Force
    $budget = [int64](128GB)
    try { $budget = [Math]::Min([int64](128GB), [int64](Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory + [int64](8GB)) } catch {}
    $cfg | Add-Member -NotePropertyName memory_max_bytes -NotePropertyValue $budget -Force
    Write-Utf8NoBomFile -Path $cfgPath -Content ($cfg | ConvertTo-Json -Depth 5)
    Write-Host "Memory helper verified. Memory capture requires Administrator and sufficient disk space."
  } catch { Write-Warning "Optional memory helper was not provisioned: $($_.Exception.Message)" }
}
Write-Host "Agent: $agentExe"
Write-Host "State: $stateDir"
Write-Host "Controller: $($bootstrap.controller_url)"
Write-Host "Enrollment is complete; an online heartbeat confirms connectivity."
if (-not $NoStart) {
  Write-Host "Starting foreground agent. Ctrl+C stops it."
  & $agentExe --state $stateDir
  if ($LASTEXITCODE -ne 0) { throw "Agent exited with an error. Review the output above." }
}
