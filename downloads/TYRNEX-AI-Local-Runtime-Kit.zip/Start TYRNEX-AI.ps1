param(
  [ValidateSet("dashboard", "doctor", "wizard")]
  [string]$Mode = "dashboard",
  [string]$HostName = "127.0.0.1",
  [int]$Port = 8765,
  [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
if (-not $env:TYRNEX_VOLATILITY) {
  $env:TYRNEX_VOLATILITY = "1"
}
$python = Join-Path $root ".venv\Scripts\python.exe"
function Test-PythonRuntime {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { return $false }
  try {
    & $Path -c "import sys; print(sys.executable)" *> $null
    return $LASTEXITCODE -eq 0
  } catch {
    return $false
  }
}
if (-not (Test-PythonRuntime $python)) {
  Write-Host "Runtime is missing, broken, or was moved from another machine. Running first-run setup..." -ForegroundColor Yellow
  & (Join-Path $root "Run This First.ps1") -NoStart -SkipToolBootstrap
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
if (-not (Test-PythonRuntime $python)) {
  Write-Host "Runtime is not installed yet. Run 'Run This First.cmd' after installing Python 3.11+." -ForegroundColor Red
  exit 1
}
$env:PYTHONPATH = "$root;$env:PYTHONPATH"
New-Item -ItemType Directory -Path (Join-Path $root "data") -Force | Out-Null

if ($Mode -eq "doctor") {
  & $python -m tyrnex_ai.cli doctor
  exit $LASTEXITCODE
}
if ($Mode -eq "wizard") {
  & $python -m tyrnex_ai.cli wizard
  exit $LASTEXITCODE
}

$args = @("-m", "tyrnex_ai.cli", "dashboard", "--db", ".\data\TYRNEX-AI.db", "--host", $HostName, "--port", "$Port")
if (-not $NoBrowser) {
  $args += "--open"
}
& $python @args
