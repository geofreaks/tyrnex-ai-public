param(
  [ValidateSet("dashboard", "doctor", "wizard")]
  [string]$Mode = "dashboard",
  [string]$HostName = "127.0.0.1",
  [int]$Port = 8765,
  [switch]$NoBrowser
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $python)) {
  Write-Host "Runtime is not installed yet. Run 'Run This First.cmd' first." -ForegroundColor Red
  exit 1
}
$env:PYTHONPATH = "$root;$env:PYTHONPATH"
New-Item -ItemType Directory -Path (Join-Path $root "data") -Force | Out-Null

if ($Mode -eq "doctor") {
  & $python -m tyrnex_ai.cli doctor
  exit $LASTEXITCODE
}
if ($Mode -eq "wizard") {
  & $python -m tyrnex_ai.cli wizard
  exit $LASTEXITCODE
}

$args = @("-m", "tyrnex_ai.cli", "dashboard", "--db", ".\data\TYRNEX-AI.db", "--host", $HostName, "--port", "$Port")
if (-not $NoBrowser) {
  $args += "--open"
}
& $python @args
