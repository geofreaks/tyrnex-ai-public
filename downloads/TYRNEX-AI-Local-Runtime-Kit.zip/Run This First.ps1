param(
  [switch]$NoStart,
  [switch]$SkipToolBootstrap
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$venv = Join-Path $root ".venv"
$python = Join-Path $venv "Scripts\python.exe"

function Test-PythonRuntime {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) {
    return $false
  }
  try {
    & $Path -c "import sys; print(sys.executable)" *> $null
    return $LASTEXITCODE -eq 0
  } catch {
    return $false
  }
}

function Reset-PortableVenv {
  if (-not (Test-Path -LiteralPath $venv)) {
    return
  }
  $rootResolved = (Resolve-Path -LiteralPath $root).Path
  $venvResolved = (Resolve-Path -LiteralPath $venv).Path
  if (-not $venvResolved.StartsWith($rootResolved, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to remove unexpected venv path: $venvResolved"
  }
  Write-Host "Existing .venv is not usable on this machine. Rebuilding local runtime environment..." -ForegroundColor Yellow
  Remove-Item -LiteralPath $venvResolved -Recurse -Force
}

function Require-Command {
  param([string]$Name, [string]$Hint)
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    Write-Host "$Name was not found." -ForegroundColor Red
    Write-Host $Hint
    exit 1
  }
}

Require-Command python "Install Python 3.11 or newer, then run this again."

if (-not (Test-PythonRuntime $python)) {
  Reset-PortableVenv
  Write-Host "Creating local runtime environment..."
  python -m venv $venv
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

Write-Host "Installing TYRNEX-AI runtime dependencies..."
& $python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $python -m pip install "bcrypt>=4.1.0" "certifi>=2024.0.0" "flask==3.0.3" "openai==1.54.0" "python-docx>=1.1.2" "reportlab>=4.2.0" "pypdf>=4.0.0"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$env:PYTHONPATH = "$root;$env:PYTHONPATH"
& $python -c "import tyrnex_ai.cli; print('TYRNEX-AI protected runtime import: ok')"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if (-not $SkipToolBootstrap) {
  Write-Host "Checking/installing bootstrap-supported security tools. Already-present tools are skipped."
  & $python -m tyrnex_ai.cli bootstrap-tools
  if ($LASTEXITCODE -ne 0) {
    Write-Host "Some optional tools could not be installed automatically. The dashboard can still run; use Doctor for details." -ForegroundColor Yellow
    $global:LASTEXITCODE = 0
  }
}

if (-not $NoStart) {
  & (Join-Path $root "Start TYRNEX-AI.ps1")
}
