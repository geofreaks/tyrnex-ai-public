﻿TYRNEX-AI Local Runtime Kit

Purpose
- Run TYRNEX-AI locally without requiring private GitHub repository access.
- Protect the private source tree by shipping a compiled Python-bytecode runtime instead of raw .py source files.
- Keep case data, uploads, exports, and reports on the local machine by default.

Start
1. Extract this zip.
2. Run "Run This First.cmd".
3. After first setup, use "Start TYRNEX-AI.cmd".
4. Use "Install All Tools.cmd" when you want to force scanner/tool bootstrap again.
5. Use "Install OWASP ZAP Integration.cmd" or "Install Metasploit Integration.cmd" for optional external app wiring.
6. Use "Check Optional Integrations.cmd" to rerun Doctor.

Defaults
- Dashboard: http://127.0.0.1:8765
- Local database: .\data\TYRNEX-AI.db
- Tool folder: .\tools

Protection notes
- This kit does not contain the private Git repo, .git metadata, raw tests, raw case evidence, .env files, API keys, or bundled scanner binaries.
- This kit also omits raw vulnerable-lab application source. Lab ranges remain a private/developer build feature.
- It is code-safe for public downloads in the same practical sense as any local protected runtime: raw source is removed, but determined reverse engineering of local software is never impossible.
- Keep proprietary development history and raw source in the private repo.

Operational safety
- Only assess systems you own or are authorized to test.
- TYRNEX-AI keeps exploit execution blocked in product workflows; Metasploit remains check-only.
