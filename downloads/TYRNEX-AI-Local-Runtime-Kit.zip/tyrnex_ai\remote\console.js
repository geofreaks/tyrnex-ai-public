'use strict';
let token = '', session = 0, snapshot = {devices: [], tasks: []}, controllerState = null, reportText = '', reportId = '', reportAction='report', reportQuery='', reportDownloadName='tyrnex-remote-report';
let busy=false, refreshing=false, pendingBatch=null, taskOffset=0, desiredCase=new URLSearchParams(location.search).get('case');
let desiredTarget=new URLSearchParams(location.search).get('target')||'', desiredTargetApplied=false;
const selected=new Set(), embedded=location.pathname.startsWith('/remote-devices/');
const retestKeys=new Map();
const deployRuns=[];
const base=embedded?'/api/remote-operator/':'/operator/';
const el = id => document.getElementById(id);
const installerButton=document.createElement('button');
installerButton.type='button';
installerButton.id='download-agent-installer';
installerButton.textContent='Download agent installer';
installerButton.hidden=!embedded;
el('select-connected').parentElement.append(installerButton);
const deployButton=document.createElement('button');
deployButton.type='button';
deployButton.id='deploy-agent';
deployButton.textContent='Deploy agent';
deployButton.hidden=!embedded;
el('select-connected').parentElement.append(deployButton);
installerButton.addEventListener('click',async()=>{
  if(!el('case').value){message('Select a case before creating an enrollment package.',true);return;}
  if(controllerState?.stale_host){
    message(`Remote controller identity is still configured for ${controllerState.host}, but this dashboard is open at ${location.hostname}. Reset and recreate the controller identity, then download a fresh installer.`,true);
    return;
  }
  installerButton.disabled=true;
  try {
    const response=await fetch(base+'enrollment-package',{method:'POST',headers:headers(),
      body:JSON.stringify({case:el('case').value,dashboard_url:location.origin})});
    if(!response.ok){const error=await response.json();throw new Error(error.error||'Installer creation failed');}
    const url=URL.createObjectURL(await response.blob()),link=document.createElement('a');
    link.href=url;link.download='TYRNEX-Agent-Installer.zip';link.click();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
    message('Installer package created for one device; enrollment expires in 30 minutes. Treat the package as a credential.');
  } catch(error){message(error.message,true);}
  finally{installerButton.disabled=false;}
});
deployButton.addEventListener('click',()=>{
  if(!el('case').value){message('Select a case before deploying an agent.',true);return;}
  if(controllerState?.stale_host){
    message(`Remote controller identity is still configured for ${controllerState.host}, but this dashboard is open at ${location.hostname}. Reset and recreate the controller identity, then deploy a fresh agent.`,true);
    return;
  }
  const current=selectedDevice();
  if(current)el('deploy-target').value=inventoryOf(current).host||current.label||el('deploy-target').value;
  el('deploy-current-status').textContent='Ready to deploy. Status will appear in Agent deployment after submit.';
  el('deploy-dialog').showModal();
});
function headers(){
  const h={'Content-Type':'application/json','X-Tyrnex-Remote':'1'};
  if(!embedded) h.Authorization='Bearer '+token;
  return h;
}
const names = {'inventory.snapshot':'Host inventory','host.posture':'Host posture assessment','evidence.logs':'Event logs','evidence.disk_triage':'Focused disk triage','evidence.memory':'Memory capture','network.connect.v1':'Network reachability and segmentation','scan.vuln':'Vulnerability scan','scan.web':'Web app scan','scan.ad':'AD / Kerberos posture','endpoint.lock':'Lock workstation','endpoint.restart':'Restart endpoint','endpoint.shutdown':'Shutdown endpoint','endpoint.quarantine.enable':'Quarantine endpoint','endpoint.quarantine.disable':'Release quarantine'};
names['network.http.v1']='HTTP/TLS configuration validation';
const httpOption=document.createElement('option');httpOption.value='network.http.v1';httpOption.textContent=names[httpOption.value];el('kind').append(httpOption);
for(const [kind,label] of [['evidence.disk.v1','Selected disk artifacts'],['scan.vuln','Vulnerability scan'],['scan.web','Web app scan'],['scan.ad','AD / Kerberos posture'],['endpoint.lock','Lock workstation'],['endpoint.restart','Restart endpoint'],['endpoint.shutdown','Shutdown endpoint'],['endpoint.quarantine.enable','Quarantine endpoint'],['endpoint.quarantine.disable','Release quarantine'],['campaign','Remote assessment campaign']]){
  names[kind]=label;const option=node('option',label);option.value=kind;el('kind').append(option);
}
function selectedStages(){
  const stages=[];
  if(el('campaign-disk-triage').checked)stages.push({kind:'evidence.disk_triage'});
  else for(const [id,kind] of [['posture','host.posture'],['logs','evidence.logs'],['disk','evidence.disk.v1']])if(el('campaign-'+id).checked)stages.push({kind});
  if(el('campaign-memory').checked)stages.push({kind:'evidence.memory'});
  if(el('campaign-network').value)stages.push({kind:el('campaign-network').value});
  return stages;
}
function networkKind(){return el('kind').value==='campaign'?el('campaign-network').value:el('kind').value;}
function message(text, error=false) { el('message').textContent=text; el('message').className=error?'danger':''; }
function renderControllerState(state){
  controllerState=state||null;
  if(!embedded)return;
  if(!state){
    el('listener-status').textContent='Listener status unavailable';
    installerButton.disabled=true;
    deployButton.disabled=true;
    installerButton.title='Controller status unavailable';
    deployButton.title='Controller status unavailable';
    return;
  }
  if(state.stale_host){
    el('listener-status').textContent=`Controller identity stale: saved ${state.host}, current dashboard ${location.hostname}. Reset and recreate before enrolling agents.`;
    installerButton.disabled=true;
    deployButton.disabled=true;
    installerButton.title='Reset and recreate the remote controller identity before downloading an installer.';
    deployButton.title='Reset and recreate the remote controller identity before deploying an agent.';
    return;
  }
  el('listener-status').textContent=state.running?'Listener running':'Listener stopped; collections wait until started';
  installerButton.disabled=false;
  deployButton.disabled=false;
  installerButton.title='';
  deployButton.title='';
}
async function api(path, data) {
  const response=await fetch(base+path,{method:data?'POST':'GET',headers:headers(),body:data?JSON.stringify(data):undefined});
  const value=await response.json(); if(!response.ok) throw new Error(value.error||'Request failed'); return value;
}
function node(tag,text,cls){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;}
function options(id,rows){const s=el(id),selected=s.value;s.replaceChildren();for(const row of rows){const o=node('option',row.label);o.value=row.value;s.append(o);}if([...s.options].some(o=>o.value===selected))s.value=selected;}
function addDeployRun(run){deployRuns.unshift(run);while(deployRuns.length>20)deployRuns.pop();renderDeployStatus();}
function matchingDeployDevice(run){
  const wanted=String(run.target||'').toLowerCase();
  return snapshot.devices.find(d=>{
    const inv=inventoryOf(d),values=[d.label,inv.host,...(Array.isArray(inv.ipv4)?inv.ipv4:[])].filter(Boolean).map(v=>String(v).toLowerCase());
    return values.includes(wanted);
  });
}
function renderDeployStatus(){
  const list=el('deploy-status');
  list.replaceChildren();
  if(!deployRuns.length){
    const empty=node('div',undefined,'deploy-empty');
    empty.append(node('strong','No deployments this session'),node('span','Use Deploy agent for a direct push, or Download agent installer for manual enrollment.'));
    list.append(empty);
    return;
  }
  for(const run of deployRuns){
    const matched=matchingDeployDevice(run);
    if(matched?.seen&&run.status==='launched'){run.status=matched.online?'connected':'enrolled';run.detail=matched.online?'Agent connected to controller.':'Agent enrolled; waiting for next heartbeat.';}
    const item=node('div',undefined,'deploy-item '+run.status);
    const main=node('div');
    main.append(node('strong',run.target),node('small',[run.username,run.destination].filter(Boolean).join(' | ')));
    const state=node('div',undefined,'deploy-state');
    state.append(node('span',run.status.replaceAll('_',' '),'pill'),node('small',run.detail||''));
    item.append(main,state);
    list.append(item);
  }
}
function batchDevices(){return snapshot.devices.filter(d=>!d.revoked&&(el('scope').value==='connected'?d.online:el('scope').value==='selected'?selected.has(d.id):d.id===el('device').value)).map(d=>d.id);}
function inventoryOf(device){try{return typeof device?.inventory==='string'?JSON.parse(device.inventory):device?.inventory||{};}catch{return {};}}
function selectedDevice(){return snapshot.devices.find(d=>d.id===el('device').value);}
function capabilitiesOf(device){const inv=inventoryOf(device);return Array.isArray(inv.capabilities)?inv.capabilities.filter(k=>k!=='endpoint.quarantine.enable'||inv.containment_schema===2):[];}
function scanKinds(){return ['scan.vuln','scan.web','scan.ad'];}
function retestableKinds(){return ['host.posture','evidence.logs','evidence.disk_triage','evidence.disk.v1','network.connect.v1','network.http.v1','scan.vuln','scan.web','scan.ad'];}
function cidrForTarget(value){
  const item=String(value||'').split(',')[0].trim();
  const host=item.replace(/^https?:\/\//i,'').split('/')[0].split(':')[0].trim();
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(host)?host+'/32':item.includes('/')?item:'';
}
function prefillRemoteNetworkTarget(value){
  const cleaned=String(value||'').split(',').map(s=>s.trim()).filter(Boolean).join('\n');
  if(!cleaned)return;
  el('kind').value='network.connect.v1';
  el('network-targets').value=cleaned;
  const allowed=cidrForTarget(cleaned);
  if(allowed)el('network-allowed').value=allowed;
  updateScope();
  message('Remote network runner is staged with the Discover target. Select an endpoint and confirm authorization before queueing.');
}
function formatBytes(value){
  const n=Number(value);
  if(!Number.isFinite(n)||n<=0)return '';
  const units=['B','KiB','MiB','GiB','TiB'];let size=n,i=0;
  while(size>=1024&&i<units.length-1){size/=1024;i++;}
  return (i?size.toFixed(size>=10?1:2):String(Math.round(size)))+' '+units[i];
}
function osDetail(inv){
  const raw=String(inv.os_caption||inv.os||inv.platform||'').trim();
  let label=raw&&!/^windows_nt$/i.test(raw)?raw:'';
  const build=Number(inv.os_build||0);
  const isWindows=/windows/i.test([raw,inv.platform].filter(Boolean).join(' '));
  if(!label&&isWindows&&build>=22000)label='Windows 11';
  else if(!label&&isWindows&&build>=10240)label='Windows 10';
  else if(!label&&isWindows)label='Windows details pending inventory refresh';
  const versionBits=[];
  if(inv.os_display_version)versionBits.push(inv.os_display_version);
  else if(inv.os_release_id)versionBits.push(inv.os_release_id);
  if(inv.os_version)versionBits.push(inv.os_version);
  if(inv.os_build)versionBits.push('build '+inv.os_build);
  if(inv.os_ubr!=null)versionBits.push('UBR '+inv.os_ubr);
  const extras=[inv.os_edition,inv.os_installation_type,inv.os_architecture].filter(Boolean).join(' / ');
  return [label||raw,versionBits.join(' / '),extras].filter(Boolean).join(' | ');
}
function renderDisks(inv){
  const disks=Array.isArray(inv.disks)?inv.disks:[];
  if(!disks.length)return 'Fixed disks: not reported';
  return 'Fixed disks: '+disks.map(d=>{
    const name=[d.device_id,d.volume_name].filter(Boolean).join(' ');
    const free=formatBytes(d.free_bytes),size=formatBytes(d.size_bytes);
    const used=(Number(d.size_bytes)>0&&Number(d.free_bytes)>=0)?` (${Math.round((1-Number(d.free_bytes)/Number(d.size_bytes))*100)}% used)`:'';
    return `${name||'disk'} ${free||'unknown free'} free${size?' of '+size:''}${used}${d.file_system?' '+d.file_system:''}`;
  }).join(' | ');
}
function agentDetail(inv){
  const details=[];
  if(inv.agent_protocol)details.push('Agent protocol '+inv.agent_protocol);
  details.push(inv.capability_schema===1?'Capabilities current':'Refresh inventory with the updated agent for current capability status');
  if(inv.memory_status)details.push('Memory: '+inv.memory_status);
  return details.join(' | ');
}
function memoryRepairHint(devices){
  const rows=[];
  for(const device of devices){
    const inv=inventoryOf(device),caps=capabilitiesOf(device),label=device.label||device.id;
    if(caps.includes('evidence.memory'))continue;
    if(inv.admin===false)rows.push(label+': start the foreground agent as Administrator, then refresh endpoint inventory');
    else if(inv.memory_status)rows.push(label+': '+inv.memory_status);
    else if(inv.capability_schema!==1)rows.push(label+': run Refresh endpoint inventory after the agent connects');
    else rows.push(label+': rerun Install Remote Agent.cmd, confirm WinPmem is downloaded and pinned, then refresh endpoint inventory');
  }
  return rows.join('; ');
}
function blockQueue(reason){
  el('queue').disabled=true;
  el('queue').title=reason;
  if(reason)el('queue').textContent='Unavailable';
}
function updateScope(){
  const campaign=el('kind').value==='campaign',kind=networkKind();
  const network=['network.connect.v1','network.http.v1'].includes(kind),http=kind==='network.http.v1';
  const endpointAction=kind.startsWith('endpoint.');
  const controllerScan=scanKinds().includes(kind);
  el('campaign-plan').hidden=!campaign;el('campaign-plan').disabled=!campaign;
  const disk=el('kind').value==='evidence.disk.v1'||campaign&&el('campaign-disk').checked;
  el('disk-plan').hidden=!disk;el('disk-plan').disabled=!disk;
  el('scan-plan').hidden=!controllerScan;el('scan-plan').disabled=!controllerScan;
  for(const id of ['scan-collection-field','scan-kerb-field'])el(id).hidden=kind!=='scan.ad';
  for(const id of ['scan-port-mode-field','scan-service-depth-field','scan-nse-level-field','scan-timing-field'])el(id).hidden=kind!=='scan.vuln';
  el('scan-ports-field').hidden=kind!=='scan.vuln'||el('scan-port-mode').value!=='custom';
  el('scan-profile-field').hidden=kind==='scan.ad';
  el('queue').textContent=campaign?'Queue campaign':'Queue task';
  el('http-scheme-field').hidden=!http;el('http-scheme').disabled=!http;
  el('network-timeout-label').textContent=http?'Request deadline (milliseconds)':'Connect timeout (milliseconds)';
  el('network-expectation').disabled=http;
  if(http)el('network-expectation').value='observe';
  el('network-plan').hidden=!network;el('network-plan').disabled=!network;el('scope').disabled=network||campaign;
  if(network||campaign)el('scope').value='single';
  if(controllerScan&&el('scope').value==='connected')el('scope').value='selected';
  el('single-device').hidden=el('scope').value!=='single';
  const bundled=campaign&&el('campaign-disk-triage').checked;
  for(const id of ['campaign-posture','campaign-logs','campaign-disk']){
    el(id).disabled=bundled;
  }
  const diskOption=el('campaign-disk-triage');
  if(campaign&&diskOption.checked){
    el('campaign-posture').checked=false;el('campaign-logs').checked=false;el('campaign-disk').checked=false;
  }
  const ids=batchDevices(),offline=snapshot.devices.filter(d=>ids.includes(d.id)&&!d.online).length;
  el('selection-summary').textContent=`${ids.length} endpoint(s) selected`+(offline?`; ${offline} offline, jobs wait for reconnection`:'');
  const viewer=snapshot.operator?.role==='viewer';
  el('task-form').parentElement.hidden=viewer;
  el('queue').disabled=busy||!ids.length||viewer;
  el('queue').title=busy?'Busy refreshing or queueing':!ids.length?'Select at least one endpoint':viewer?'Viewer role cannot queue work':'';
  if(network){
    const device=selectedDevice(),inv=inventoryOf(device);
    options('network-source',(inv.addresses||[]).filter(a=>/^\d+\./.test(a)).map(a=>({value:a.split('/')[0],label:a})));
    const capable=(inv.capabilities||[]).includes(kind);
    if(!capable){
      const reason=http?'HTTP validation unavailable. Update the agent, enable its network-runner and HTTP-validation roles, then collect inventory.':'This endpoint has not advertised network-runner capability. Enable its runner role and collect inventory.';
      el('selection-summary').textContent=reason;
      blockQueue(reason);
    } else {
      el('queue').disabled=busy||!ids.length||viewer;
    }
  }
  if(endpointAction){
    const missing=[];
    for(const device of snapshot.devices.filter(d=>ids.includes(d.id))){
      if(!capabilitiesOf(device).includes(kind))missing.push(device.label||device.id);
    }
    if(missing.length){
      const reason=`${names[kind]||kind} unavailable on: ${missing.join(', ')}. Start the agent as Administrator if this action requires Windows firewall or power control, then refresh endpoint inventory.`;
      el('selection-summary').textContent=reason;
      blockQueue(reason);
    }
  }
  if(controllerScan){
    const missing=[];
    for(const device of snapshot.devices.filter(d=>ids.includes(d.id))){
      if(!capabilitiesOf(device).includes(kind))missing.push(device.label||device.id);
    }
    if(missing.length){
      const reason=`${names[kind]} unavailable on: ${missing.join(', ')}. Update the agent and refresh endpoint inventory.`;
      el('selection-summary').textContent=reason;
      blockQueue(reason);
    }
  }
  if(disk||campaign){
    const required=campaign?selectedStages().map(s=>s.kind):['evidence.disk.v1'];
    const missing=new Set();
    for(const device of snapshot.devices.filter(d=>ids.includes(d.id))){
      const inv=inventoryOf(device);
      for(const kind of required)if(!(inv.capabilities||[]).includes(kind))missing.add(names[kind]||kind);
    }
    if(missing.size){
      const selectedDevices=snapshot.devices.filter(d=>ids.includes(d.id));
      const hint=missing.has(names['evidence.memory'])?memoryRepairHint(selectedDevices):'Update the agent or local opt-in, then refresh inventory.';
      const reason='Unavailable on selected endpoint(s): '+[...missing].join(', ')+'. '+hint;
      el('selection-summary').textContent=reason;
      blockQueue(reason);
    }
    if(!required.length||disk&&!['prefetch','scheduled_tasks','firewall_logs'].some(p=>el('disk-'+p).checked))blockQueue('Select at least one disk artifact profile.');
  }
}
function scanParameters(kind){
  if(!scanKinds().includes(kind))return null;
  const params={};
  if(kind==='scan.vuln'){
    params.nmap_port_mode=el('scan-port-mode').value;
    params.nmap_service_depth=el('scan-service-depth').value;
    params.nmap_nse_level=el('scan-nse-level').value;
    params.nmap_timing=el('scan-timing').value;
    if(el('scan-port-mode').value==='custom'){
      const ports=el('scan-ports').value.split(',').map(s=>Number(s.trim())).filter(n=>Number.isInteger(n)&&n>=1&&n<=65535);
      if(ports.length)params.ports=[...new Set(ports)];
    }
    params.scan_profile=el('scan-profile').value;
  } else if(kind==='scan.web'){
    params.scan_profile=el('scan-profile').value;
    params.zap_mode='baseline';
  } else if(kind==='scan.ad'){
    params.collection=el('scan-collection').value;
    params.include_kerberoast=el('scan-kerberoast').checked;
  }
  return params;
}
function factsForInventory(inv){
  const user=[inv.domain,inv.user||inv.agent_user].filter(Boolean).join('\\');
  return [
    ['Host',inv.host],
    ['OS',osDetail(inv)],
    ['User',user],
    ['Arch',inv.architecture],
    ['Admin',inv.admin===true?'yes':inv.admin===false?'no':'unknown'],
    ['Memory total',formatBytes(inv.memory_total_bytes)],
    ['Memory available',formatBytes(inv.memory_available_bytes)],
    ['Agent drive free',formatBytes(inv.agent_free_bytes)],
    ['Memory needs',formatBytes(inv.memory_required_bytes)],
    ['Memory ready',inv.memory_ready===true?'yes':inv.memory_ready===false?'no':'unknown'],
    ['IPv4',(inv.ipv4||[]).filter(a=>!a.startsWith('127.')&&!a.startsWith('169.254.')).join(', ')],
    ['Domain',inv.computer_domain],
    ['Hardware',[inv.computer_manufacturer,inv.computer_model].filter(Boolean).join(' ')],
  ].filter(row=>row[1]!==undefined&&row[1]!==null&&String(row[1]).trim());
}
function setFullPreset(){
  const device=selectedDevice(),caps=capabilitiesOf(device);
  el('kind').value='campaign';
  el('scope').value='single';
  const selectedDisk=caps.includes('evidence.disk.v1'),bundle=!selectedDisk&&caps.includes('evidence.disk_triage');
  el('campaign-disk-triage').checked=bundle;
  el('campaign-posture').checked=!bundle;
  el('campaign-logs').checked=!bundle;
  el('campaign-disk').checked=selectedDisk;
  el('campaign-memory').checked=caps.includes('evidence.memory');
  el('campaign-network').value='';
  el('disk-prefetch').checked=true;
  el('disk-scheduled_tasks').checked=true;
  el('disk-firewall_logs').checked=true;
  updateScope();
  message(caps.includes('evidence.memory')?'Full preset selected, including memory.':bundle?'Full preset selected with focused disk triage bundle. Memory is not advertised by this endpoint yet.':'Full preset selected. Memory is not advertised by this endpoint yet.');
}
async function openReport(id,action='report',isAction=false){
  return openReportQuery(action,'task='+encodeURIComponent(id),id,isAction?'Action receipt':'Assessment Report','tyrnex-remote-'+id);
}
async function openDeviceReport(deviceId){
  const device=snapshot.devices.find(d=>d.id===deviceId),caseKey=el('case').value||'';
  const label=(device?.label||deviceId).replace(/[^A-Za-z0-9_.-]+/g,'_');
  const query='device='+encodeURIComponent(deviceId)+(caseKey?'&case='+encodeURIComponent(caseKey):'');
  return openReportQuery('device-report',query,deviceId,'Remote Device Combined Report','tyrnex-remote-device-'+label+(caseKey?'-'+caseKey:''));
}
async function openReportQuery(action,query,id,title,downloadName){
  const active=session;
  try{const r=await api(action+'?'+query);if((!embedded&&!token)||active!==session)return;
    reportText=r.markdown;reportId=id;reportAction=action;reportQuery=query;reportDownloadName=downloadName||('tyrnex-remote-'+id);
    el('download-zip').hidden=action!=='device-report';
    el('report-text').textContent=reportText;el('report').querySelector('h2').textContent=title||'Assessment Report';el('report').showModal();
  }catch(e){if(active===session)message(e.message,true);}
}
function renderCampaigns(){
  const rows=snapshot.campaigns||[],body=el('campaigns');body.replaceChildren();el('campaign-section').hidden=!rows.length;
  for(const c of rows){
    const tr=node('tr'),identity=node('td',snapshot.devices.find(d=>d.id===c.device)?.label||c.device);identity.append(node('small',c.case_key));
    const state=node('td',c.status.replaceAll('_',' '));state.append(node('small',c.detail));
    const stages=node('td',`${c.finished}/${c.stages.length} finished`),details=node('details');details.append(node('summary','Stage status'));
    for(const stage of c.stages)details.append(node('small',`${names[stage.kind]||stage.kind}: ${stage.status.replaceAll('_',' ')} - ${stage.detail}`));stages.append(details);
    const actions=node('td');
    if(c.report_available){const button=node('button','Report');button.onclick=()=>openReport(c.id,'campaign-report');actions.append(button);}
    if(['queued','running','cancelling'].includes(c.status)&&snapshot.operator?.role!=='viewer'){
      const button=node('button','Cancel');button.disabled=!!c.cancel_requested;button.onclick=async()=>{if(!confirm('Cancel remaining stages in this campaign?'))return;try{await api('cancel-campaign',{id:c.id});await refresh();}catch(e){message(e.message,true);}};actions.append(button);
    }
    tr.append(identity,state,stages,actions);body.append(tr);
  }
}
function renderDevices(){
  const active=snapshot.devices.filter(d=>!d.revoked),container=el('devices');
  for(const id of selected)if(!active.some(d=>d.id===id))selected.delete(id);
  el('endpoint-summary').textContent=`${active.filter(d=>d.online).length} connected / ${active.length} enrolled`;
  const existing=new Map([...container.querySelectorAll('.device')].map(n=>[n.dataset.device,n]));
  if(!existing.size)container.replaceChildren();
  for(const d of snapshot.devices){
    let r=existing.get(d.id);
    if(!r){
      r=node('div',undefined,'device');r.dataset.device=d.id;
      const check=node('input');check.type='checkbox';check.setAttribute('aria-label','Select '+d.label);
      check.onchange=()=>{check.checked?selected.add(d.id):selected.delete(d.id);updateScope();};
      const identity=node('div',undefined,'identity'),details=node('details');details.append(node('summary','Device details'),node('small',d.id),node('div',undefined,'facts'),node('small',undefined,'storage'),node('small',undefined,'addresses'),node('small',undefined,'agent-detail'));identity.append(node('strong'),node('small',undefined,'inventory'),details);
      const state=node('div');state.append(node('span'),node('small',undefined,'seen'));
      const actions=node('div',undefined,'device-actions');
      const deviceReport=node('button','Export reports');deviceReport.className='device-report';deviceReport.title='Open combined remote reports for this endpoint';deviceReport.onclick=()=>openDeviceReport(d.id);
      const revoke=node('button','Revoke');revoke.className='revoke-device';revoke.onclick=async()=>{if(!confirm('Revoke '+d.label+'? Further connections are blocked and pending collections are cancelled. Evidence already received can finish analysis. This does not undo an endpoint action.'))return;try{await api('revoke',{device:d.id});message('Revoked '+d.label+'.');await refresh();}catch(e){message(e.message,true);}};
      const remove=node('button','Delete');remove.className='delete-device danger-button';remove.onclick=async()=>{if(!confirm('Delete '+d.label+' from Remote Devices? Further connections are blocked and pending collections are cancelled. Received evidence and case reports remain. This does not uninstall the agent or undo an endpoint action.'))return;try{await api('delete-device',{device:d.id});selected.delete(d.id);message('Deleted remote device '+d.label+'.');await refresh();}catch(e){message(e.message,true);}};
      actions.append(deviceReport,revoke,remove);
      r.append(check,identity,state,actions);container.append(r);
    }
    existing.delete(d.id);r.querySelector('input').checked=selected.has(d.id);r.querySelector('input').disabled=!!d.revoked;r.querySelector('.device-report').hidden=!!d.revoked;r.querySelector('.revoke-device').hidden=!!d.revoked||snapshot.operator?.role!=='admin';r.querySelector('.delete-device').hidden=snapshot.operator?.role!=='admin';
    r.querySelector('strong').textContent=d.label;
    const state=r.querySelector('span');state.textContent=d.revoked?'Revoked':d.online?'Connected':d.seen?'Offline':'Awaiting first connection';state.className=d.online?'online':'offline';
    r.querySelector('.seen').textContent=d.seen?'Last contact: '+new Date(d.seen*1000).toLocaleString():'No heartbeat received';
    const inv=inventoryOf(d);
    const addresses=Array.isArray(inv.addresses)?inv.addresses:[];
    const ipv4=Array.isArray(inv.ipv4)?inv.ipv4:addresses.filter(a=>/^\d+\./.test(a));
    const summaryIp=ipv4.filter(a=>!a.startsWith('127.')&&!a.startsWith('169.254.')).join(', ');
    const user=[inv.domain,inv.user||inv.agent_user].filter(Boolean).join('\\');
    r.querySelector('.inventory').textContent=[inv.host,summaryIp,osDetail(inv),user,(inv.capabilities||[]).includes('network.connect.v1')?'Network runner':'Endpoint collector'].filter(Boolean).join(' | ');
    const facts=r.querySelector('.facts');facts.replaceChildren(...factsForInventory(inv).map(([k,v])=>node('small',`${k}: ${v}`)));
    r.querySelector('.storage').textContent=renderDisks(inv);
    r.querySelector('.addresses').textContent=addresses.length?'Interfaces: '+addresses.join(', '):'Inventory not yet collected';
    r.querySelector('.agent-detail').textContent=agentDetail(inv);
  }
  for(const r of existing.values())r.remove();
  if(!snapshot.devices.length)container.replaceChildren(node('p','No enrolled endpoints'));
}
function renderTasks(){
  const total=snapshot.task_total??snapshot.tasks.length;taskOffset=snapshot.task_offset||0;
  el('queue-range').textContent=total?`${taskOffset+1}-${taskOffset+snapshot.tasks.length} of ${total} collections`:'No collections';
  el('queue-prev').disabled=taskOffset===0;el('queue-next').disabled=taskOffset+snapshot.tasks.length>=total;
  const q=el('filter').value.toLowerCase(),status=el('status-filter').value,body=el('tasks');body.replaceChildren();
  for(const t of snapshot.tasks){const d=snapshot.devices.find(d=>d.id===t.device);const label=d?.label||t.device;
    if(status&&t.status!==status||!`${label} ${t.case_key} ${t.kind} ${t.status} ${t.detail}`.toLowerCase().includes(q))continue;
    const tr=node('tr'),who=node('td',label);who.append(node('small',t.case_key));tr.append(who,node('td',names[t.kind]||t.kind));
    const state=node('td',t.status.replaceAll('_',' '));state.append(node('small',t.detail||(t.status==='queued'?(d?.online?'Waiting for collection slot':'Waiting for endpoint connection'):'')));tr.append(state);
    const pct=node('td',`${t.progress}%`),bar=node('progress');bar.max=100;bar.value=t.progress;pct.append(bar);tr.append(pct);
    const action=node('td');
    if(snapshot.operator?.role!=='viewer'&&['queued','running','received'].includes(t.status)){const b=node('button','Cancel');b.onclick=async()=>{b.disabled=true;try{await api('cancel',{id:t.id});await refresh();}catch(e){message(e.message,true);}finally{b.disabled=false;}};action.append(b);}
    if(t.report_available||['completed','completed_with_warnings'].includes(t.status)){const b=node('button','Export');b.title=t.kind.startsWith('endpoint.')?'Open action receipt and export formats':'Open assessment report and export formats';b.onclick=()=>openReport(t.id,'report',t.kind.startsWith('endpoint.'));action.append(b);}
    if(snapshot.operator?.role==='admin'){const b=node('button','Delete');b.className='danger-button delete-task';b.onclick=async()=>{if(!confirm('Delete this Work Queue item? This removes the remote collection/action row and its remote run folder. It does not uninstall the agent or undo endpoint actions already run.'))return;b.disabled=true;try{await api('delete-task',{id:t.id});message('Deleted Work Queue item.');await refresh();}catch(e){message(e.message,true);}finally{b.disabled=false;}};action.append(b);}
    if(retestableKinds().includes(t.kind)&&snapshot.operator?.role!=='viewer'&&['completed','completed_with_warnings'].includes(t.status)){
      const b=node('button','Retest');b.title='Repeat the original authorized scope, endpoint and task parameters';
      b.onclick=async()=>{if(!confirm('Repeat this task using its original case, endpoint, scope and parameters?'))return;
        if(!retestKeys.has(t.id))retestKeys.set(t.id,requestKey());
        b.disabled=true;try{await api('retest',{id:t.id,request_key:retestKeys.get(t.id),authorized:true});retestKeys.delete(t.id);message('Targeted retest queued with the original scope.');await refresh();}
        catch(e){message(e.message,true);}finally{b.disabled=false;}};action.append(b);
    }
    tr.append(action);body.append(tr);
  }
  if(!body.children.length){const tr=node('tr'),td=node('td','No matching collections');td.colSpan=5;tr.append(td);body.append(tr);}
}
async function refresh(){if((!embedded&&!token)||refreshing)return;refreshing=true;const active=session;
 try{const value=await api('status'+(taskOffset?'?offset='+taskOffset:''));if((!embedded&&!token)||active!==session)return;snapshot=value;el('workspace').hidden=false;el('login').hidden=true;
 renderDevices();renderDeployStatus();options('device',snapshot.devices.filter(d=>!d.revoked).map(d=>({value:d.id,label:d.label+(d.online?'':' (offline)')})));options('case',snapshot.cases.map(c=>({value:c.key,label:c.name+' ('+c.key+')'})));
 if(desiredCase&&snapshot.cases.some(c=>c.key===desiredCase)){el('case').value=desiredCase;desiredCase=null;}
 if(desiredTarget&&!desiredTargetApplied){prefillRemoteNetworkTarget(desiredTarget);desiredTargetApplied=true;desiredTarget='';}
 updateScope();renderTasks();renderCampaigns();el('controller-address').textContent=snapshot.controller_url||'';
 if(embedded){const response=await fetch('/api/remote-controller');const state=await response.json();if(active===session)renderControllerState(response.ok?state:null);}
 }finally{refreshing=false;}
}
el('login-form').onsubmit=async e=>{e.preventDefault();session++;token=el('token').value;el('token').value='';try{await refresh();message('');}catch(error){token='';message(error.message,true);}};
el('lock').onclick=()=>{session++;token='';selected.clear();pendingBatch=null;snapshot={devices:[],tasks:[]};el('workspace').hidden=true;el('login').hidden=false;el('devices').replaceChildren();el('tasks').replaceChildren();el('campaigns').replaceChildren();el('campaign-section').hidden=true;el('report').close();el('report-text').textContent='';reportText='';reportId='';reportAction='report';reportQuery='';reportDownloadName='tyrnex-remote-report';message('Locked');};
el('refresh').onclick=()=>refresh().catch(e=>message(e.message,true));
el('inventory-refresh').onclick=()=>refresh().catch(e=>message(e.message,true));
el('filter').oninput=renderTasks;el('status-filter').onchange=renderTasks;
for(const [id,delta] of [['queue-prev',-200],['queue-next',200]])el(id).onclick=()=>{if(refreshing)return;taskOffset=Math.max(0,taskOffset+delta);refresh().catch(e=>message(e.message,true));};
el('scope').onchange=updateScope;el('device').onchange=updateScope;
el('kind').onchange=updateScope;
el('full-preset').onclick=setFullPreset;
el('refresh-inventory').onclick=async()=>{
  if(busy)return;
  const devices=batchDevices();
  if(!devices.length)return message('Select one connected endpoint first.',true);
  busy=true;updateScope();
  try{
    const key=requestKey();
    const r=await api('tasks',{devices:devices.sort(),case:el('case').value,kind:'inventory.snapshot',authorized:true,request_key:key});
    message('Queued endpoint inventory refresh for '+r.tasks.length+' endpoint(s). Wait for it to complete, then select memory again.');
    taskOffset=0;await refresh();
  }catch(e){message(e.message,true);}
  finally{busy=false;updateScope();}
};
for(const control of document.querySelectorAll('#campaign-plan input,#campaign-plan select,#disk-plan input,#scan-plan input,#scan-plan select'))control.onchange=updateScope;
el('select-connected').onclick=()=>{selected.clear();for(const d of snapshot.devices)if(d.online&&!d.revoked)selected.add(d.id);renderDevices();el('scope').value='selected';updateScope();};
el('clear-selection').onclick=()=>{selected.clear();renderDevices();updateScope();};
function requestKey(){const b=new Uint8Array(16);crypto.getRandomValues(b);return Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');}
el('task-form').onsubmit=async e=>{
 e.preventDefault();if(busy)return;const active=session,devices=batchDevices();
 if(!devices.length)return message('Select at least one enrolled endpoint.',true);
 const payload={devices:devices.sort(),case:el('case').value,kind:el('kind').value,authorized:el('authorized').checked};
 const campaign=payload.kind==='campaign',kind=networkKind();
 if(kind==='endpoint.quarantine.enable'&&!confirm('Quarantine selected endpoint(s)? This blocks inbound and outbound network traffic except TYRNEX controller access until Release quarantine is run or local firewall policy is restored.'))return;
 if(kind==='endpoint.restart'&&!confirm('Restart selected endpoint(s) in 60 seconds?'))return;
 if(kind==='endpoint.shutdown'&&!confirm('Shutdown selected endpoint(s) in 60 seconds?'))return;
 if(['network.connect.v1','network.http.v1'].includes(kind)){
   const lines=id=>el(id).value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
   const ports=el('network-ports').value.split(',').map(s=>Number(s.trim()));
   payload.parameters={source_address:el('network-source').value,source_zone:el('network-source-zone').value,
     allowed_networks:lines('network-allowed'),excluded_networks:lines('network-excluded'),
     targets:lines('network-targets').map(host=>({host,ports,expectation:el('network-expectation').value,destination_zone:el('network-dest-zone').value})),
     timeout_ms:Number(el('network-timeout').value),rate_limit:Number(el('network-rate').value),max_seconds:Number(el('network-duration').value)};
   if(kind==='network.http.v1')payload.parameters.scheme=el('http-scheme').value;
 }
 const diskParameters={profiles:['prefetch','scheduled_tasks','firewall_logs'].filter(p=>el('disk-'+p).checked)};
 if(payload.kind==='evidence.disk.v1')payload.parameters=diskParameters;
 if(scanKinds().includes(payload.kind))payload.parameters=scanParameters(payload.kind);
 if(campaign){
   payload.device=devices[0];payload.stages=selectedStages().map(stage=>({...stage,parameters:stage.kind==='evidence.disk.v1'?diskParameters:stage.kind.startsWith('network.')?payload.parameters:{}}));
   delete payload.devices;delete payload.kind;delete payload.parameters;
 }
 const signature=JSON.stringify(payload);
 if(!pendingBatch||pendingBatch.signature!==signature)pendingBatch={signature,key:requestKey()};
 busy=true;updateScope();
 try{const r=await api(campaign?'campaign':'tasks',{...payload,request_key:pendingBatch.key});if(active!==session)return;pendingBatch=null;taskOffset=0;message(`Queued ${r.tasks.length} ${campaign?'campaign stage(s)':'collection(s)'} for ${payload.case}.`);await refresh();}
 catch(error){if(active===session)message(error.message+' Retry the same selection to avoid duplicate jobs.',true);}
 finally{busy=false;updateScope();}
};
el('close-report').onclick=()=>el('report').close();
el('close-deploy').onclick=()=>el('deploy-dialog').close();
el('deploy-cancel').onclick=()=>el('deploy-dialog').close();
el('deploy-form').onsubmit=async event=>{
  event.preventDefault();
  const password=el('deploy-password').value;
  const payload={
    case:el('case').value,
    dashboard_url:location.origin,
    target:el('deploy-target').value.trim(),
    username:el('deploy-username').value.trim(),
    password,
    destination:el('deploy-destination').value.trim(),
    authorized:el('deploy-authorized').checked
  };
  if(!payload.authorized)return message('Confirm deployment authorization first.',true);
  const run={target:payload.target,username:payload.username,destination:payload.destination,status:'starting',detail:'Creating installer package and starting remote launcher.'};
  addDeployRun(run);
  el('deploy-current-status').textContent='Deploying to '+payload.target+'...';
  deployButton.disabled=true;el('deploy-submit').disabled=true;
  try{
    const result=await api('deploy-agent',payload);
    run.status='launched';
    run.detail=`Remote launcher started${result.process_id?' as PID '+result.process_id:''}. Waiting for ${result.target} to enroll and heartbeat.${result.log?' Log: '+result.log:''}`;
    renderDeployStatus();
    el('deploy-password').value='';
    el('deploy-dialog').close();
    message(`Deploy started on ${result.target}. Destination: ${result.destination}. Refresh Remote Devices after the endpoint connects.`);
    await refresh();
  }catch(error){run.status='failed';run.detail=error.message;renderDeployStatus();el('deploy-current-status').textContent='Deploy failed: '+error.message;message(error.message,true);}
  finally{payload.password='';deployButton.disabled=false;el('deploy-submit').disabled=false;}
};
el('download-report').onclick=()=>{const url=URL.createObjectURL(new Blob([reportText],{type:'text/markdown'}));const a=node('a');a.href=url;a.download=reportDownloadName+'.md';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
async function downloadReportFormat(format){
  const active=session;
  try{
    const sep=reportQuery?'&':'';
    const response=await fetch(base+reportAction+'?'+reportQuery+sep+'format='+format,{headers:headers()});
    if(!response.ok)throw new Error((await response.json()).error||'Export failed');
    const blob=await response.blob();if((!embedded&&!token)||active!==session)return;
    const url=URL.createObjectURL(blob),a=node('a');a.href=url;a.download=reportDownloadName+'.'+format;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }catch(e){if(active===session)message(e.message,true);}
}
for(const format of ['docx','pdf'])el('download-'+format).onclick=()=>downloadReportFormat(format);
el('download-zip').onclick=()=>downloadReportFormat('zip');
window.addEventListener('message',event=>{
  if(event.origin!==location.origin||event.source!==parent)return;
  if(event.data?.type==='tyrnex-case'){desiredCase=event.data.case;refresh().catch(e=>message(e.message,true));}
  if(event.data?.type==='tyrnex-remote-target'){desiredCase=event.data.case||desiredCase;desiredTarget=event.data.target||'';desiredTargetApplied=false;refresh().catch(e=>message(e.message,true));}
});
if(embedded){document.body.classList.add('embedded');el('login').hidden=true;el('lock').hidden=true;session++;refresh().catch(e=>message(e.message,true));}
setInterval(()=>{if((embedded||token)&&!document.hidden)refresh().catch(e=>message(e.message,true));},5000);
