# TYRNEX-AI true LAN rogue-device probe using a VirtualBox bridged adapter.
# Windows Home compatible path: the VM is bridged to the selected physical adapter so the router can issue a LAN DHCP lease.
param(
  [Parameter(Position = 0)]
  [ValidateSet("install", "up", "status", "down", "remove", "adapters")]
  [string]$Command = "status",

  [string]$AdapterName = "",
  [string]$VmName = "TYRNEX-AI-Rogue-LAN-Probe",
  [string]$IsoUrl = "https://dl-cdn.alpinelinux.org/alpine/v3.20/releases/x86_64/alpine-virt-3.20.3-x86_64.iso",
  [switch]$NoElevate
)

$ErrorActionPreference = "Continue"
$Root = Split-Path -Parent $PSScriptRoot
$ProbeRoot = Join-Path $Root "data\rogue-lan-vbox-probe"
$IsoPath = Join-Path $ProbeRoot "alpine-virt.iso"
$StatusPath = Join-Path $ProbeRoot "status.json"

function Test-IsAdmin {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Write-StatusJson($Data) {
  New-Item -ItemType Directory -Force -Path $ProbeRoot | Out-Null
  $copy = [ordered]@{}
  foreach ($key in $Data.Keys) { $copy[$key] = $Data[$key] }
  $copy.timestamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
  $copy | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $StatusPath -Encoding UTF8
}

function Get-VBoxManage {
  $cmd = Get-Command VBoxManage.exe -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  $default = "C:\Program Files\Oracle\VirtualBox\VBoxManage.exe"
  if (Test-Path -LiteralPath $default) { return $default }
  return ""
}

function Require-VBox {
  $vbox = Get-VBoxManage
  if (-not $vbox) {
    throw "VirtualBox is not installed. Run: rogue-lan-vbox-probe.ps1 install"
  }
  return $vbox
}

function Install-VirtualBox {
  if (Get-VBoxManage) {
    Write-Host "VirtualBox is already installed." -ForegroundColor Green
    return
  }
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "winget is not available. Install VirtualBox manually from Oracle, then rerun this probe."
  }
  Write-Host "Installing Oracle VirtualBox via winget. This may require admin approval and a reboot." -ForegroundColor Yellow
  winget install --id Oracle.VirtualBox --exact --accept-package-agreements --accept-source-agreements
  Write-Host "VirtualBox install command finished. Reboot if prompted, then run the probe again." -ForegroundColor Green
}

function Get-PhysicalAdapters {
  Get-NetAdapter -Physical -ErrorAction SilentlyContinue |
    Where-Object {
      $_.Status -eq "Up" -and
      $_.Name -notmatch "vEthernet|Hyper-V|Loopback|TAP|VPN|Virtual|Npcap|Bluetooth"
    } |
    Sort-Object -Property LinkSpeed -Descending
}

function Get-VBoxBridgeInterfaces {
  $vbox = Require-VBox
  $rows = @()
  $current = [ordered]@{}
  foreach ($line in @(& $vbox list bridgedifs 2>$null)) {
    if (-not $line.Trim()) {
      if ($current.Count) {
        $rows += [pscustomobject]$current
        $current = [ordered]@{}
      }
      continue
    }
    if ($line -match "^([^:]+):\s*(.*)$") {
      $current[$Matches[1].Trim()] = $Matches[2].Trim()
    }
  }
  if ($current.Count) { $rows += [pscustomobject]$current }
  return $rows
}

function Select-ProbeAdapter {
  if ($AdapterName) {
    $adapter = Get-NetAdapter -Name $AdapterName -ErrorAction SilentlyContinue
    if (-not $adapter) { throw "Adapter '$AdapterName' was not found." }
    return $adapter
  }
  $adapters = @(Get-PhysicalAdapters)
  if ($adapters.Count -lt 1) { throw "No connected physical adapter found." }
  return $adapters[0]
}

function Select-VBoxBridgeName {
  $bridges = @(Get-VBoxBridgeInterfaces | Where-Object { $_.Status -eq "Up" })
  if ($AdapterName) {
    $exact = $bridges | Where-Object { $_.Name -eq $AdapterName -or $_.VBoxNetworkName -eq $AdapterName } | Select-Object -First 1
    if ($exact) { return $exact.Name }
  }
  $adapter = Select-ProbeAdapter
  $byDescription = $bridges | Where-Object { $_.Name -eq $adapter.InterfaceDescription } | Select-Object -First 1
  if ($byDescription) { return $byDescription.Name }
  $byMac = $bridges | Where-Object { ($_.HardwareAddress -replace ":", "-").ToUpperInvariant() -eq $adapter.MacAddress.ToUpperInvariant() } | Select-Object -First 1
  if ($byMac) { return $byMac.Name }
  $fallback = $bridges | Where-Object { $_.Wireless -eq "No" } | Select-Object -First 1
  if ($fallback) { return $fallback.Name }
  if ($bridges.Count) { return $bridges[0].Name }
  throw "No active VirtualBox bridged interfaces found. In VirtualBox, confirm the bridged networking driver is installed for your adapter."
}

function Ensure-Iso {
  New-Item -ItemType Directory -Force -Path $ProbeRoot | Out-Null
  if (Test-Path $IsoPath) { return }
  Write-Host "Downloading live Linux probe ISO..." -ForegroundColor Cyan
  Invoke-WebRequest -Uri $IsoUrl -OutFile $IsoPath -UseBasicParsing
}

function New-ProbeMac {
  $bytes = New-Object byte[] 3
  $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
  try {
    $rng.GetBytes($bytes)
  } finally {
    $rng.Dispose()
  }
  $suffix = (($bytes | ForEach-Object { $_.ToString("X2") }) -join "")
  return "02155D$suffix"
}

function Invoke-VBox {
  param(
    [string[]]$VBoxArgs
  )
  $vbox = Require-VBox
  $output = & $vbox @VBoxArgs 2>&1
  if ($LASTEXITCODE -ne 0) {
    throw (($output | ForEach-Object { "$_" }) -join "`n")
  }
  return $output
}

function Get-VBoxVmExists {
  $vbox = Require-VBox
  & $vbox showvminfo $VmName --machinereadable 2>$null | Out-Null
  return ($LASTEXITCODE -eq 0)
}

function Get-VBoxValue([string[]]$Lines, [string]$Key) {
  $match = $Lines | Where-Object { $_ -like "$Key=*" } | Select-Object -First 1
  if (-not $match) { return "" }
  return (($match -split "=", 2)[1]).Trim('"')
}

function Ensure-IdeController {
  try {
    Invoke-VBox -VBoxArgs @("storagectl", $VmName, "--name", "IDE", "--add", "ide") | Out-Null
  } catch {
    if ($_.Exception.Message -notmatch "already exists|exists already|duplicate") {
      throw
    }
  }
}

function Ensure-ProbeVm {
  $bridgeName = Select-VBoxBridgeName
  Ensure-Iso
  if (-not (Get-VBoxVmExists)) {
    Write-Host "Creating VirtualBox bridged probe VM '$VmName'." -ForegroundColor Cyan
    Invoke-VBox -VBoxArgs @("createvm", "--name", $VmName, "--platform-architecture=x86", "--ostype", "Linux_64", "--register") | Out-Null
    Invoke-VBox -VBoxArgs @("modifyvm", $VmName, "--memory", "384", "--cpus", "1", "--audio-driver", "none", "--usb", "off", "--boot1", "net", "--boot2", "dvd", "--boot3", "none", "--nic1", "bridged", "--bridge-adapter1", $bridgeName, "--mac-address1", (New-ProbeMac)) | Out-Null
  } else {
    Invoke-VBox -VBoxArgs @("modifyvm", $VmName, "--boot1", "net", "--boot2", "dvd", "--boot3", "none", "--nic1", "bridged", "--bridge-adapter1", $bridgeName) | Out-Null
  }
  Ensure-IdeController
  Invoke-VBox -VBoxArgs @("storageattach", $VmName, "--storagectl", "IDE", "--port", "0", "--device", "0", "--type", "dvddrive", "--medium", $IsoPath) | Out-Null
}

function Get-ProbeSnapshot {
  $vbox = Require-VBox
  $exists = Get-VBoxVmExists
  $lines = @()
  if ($exists) { $lines = @(& $vbox showvminfo $VmName --machinereadable 2>$null) }
  $state = if ($exists) { Get-VBoxValue $lines "VMState" } else { "missing" }
  $mac = if ($exists) { Get-VBoxValue $lines "macaddress1" } else { "" }
  $bridge = if ($exists) { Get-VBoxValue $lines "bridgeadapter1" } else { "" }
  $guestIp = ""
  if ($exists) {
    $guest = @(& $vbox guestproperty get $VmName "/VirtualBox/GuestInfo/Net/0/V4/IP" 2>$null)
    if ($guest -and $guest[0] -match "Value:\s*(.+)$") { $guestIp = $Matches[1].Trim() }
  }
  return [ordered]@{
    tool = "tyrnex-ai-rogue-lan-vbox-probe"
    mode = "virtualbox-bridged"
    vm_name = $VmName
    vm_exists = [bool]$exists
    state = $state
    bridge_adapter = $bridge
    mac = $mac
    ip_addresses = @($guestIp | Where-Object { $_ })
    lan_visible_expected = [bool]$exists
    status_path = $StatusPath
    note = "A running VirtualBox VM with bridged PXE/network boot should request a real LAN DHCP lease. If IP is blank here, check your router DHCP/client list for the MAC."
  }
}

function Show-Status {
  try {
    $snap = Get-ProbeSnapshot
  } catch {
    $snap = [ordered]@{
      tool = "tyrnex-ai-rogue-lan-vbox-probe"
      mode = "virtualbox-bridged"
      vm_name = $VmName
      vm_exists = $false
      state = "unavailable"
      bridge_adapter = ""
      mac = ""
      ip_addresses = @()
      lan_visible_expected = $false
      status_path = $StatusPath
      note = $_.Exception.Message
    }
  }
  Write-StatusJson $snap
  Write-Host ""
  Write-Host "TYRNEX-AI VirtualBox LAN Rogue Probe" -ForegroundColor Cyan
  Write-Host ("VM:      {0} ({1})" -f $snap.vm_name, $snap.state)
  Write-Host ("Bridge:  {0}" -f $snap.bridge_adapter)
  Write-Host ("MAC:     {0}" -f $snap.mac)
  $ipText = if ($snap.ip_addresses -and $snap.ip_addresses.Count) { ($snap.ip_addresses -join ", ") } else { "(not reported yet; check router for MAC)" }
  Write-Host ("IP(s):   {0}" -f $ipText)
  Write-Host ("LAN:     {0}" -f ($(if ($snap.lan_visible_expected) { "bridged adapter expected" } else { "not active" })))
  Write-Host ("Status:  {0}" -f $snap.status_path)
  Write-Host ("Note:    {0}" -f $snap.note) -ForegroundColor DarkYellow
}

if ($Command -in @("install") -and -not (Test-IsAdmin)) {
  if ($NoElevate) {
    Write-Host "Administrator rights are required for '$Command'." -ForegroundColor Red
    exit 1
  }
  $args = @("-NoExit", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"", $Command)
  Start-Process -FilePath "powershell.exe" -ArgumentList $args -Verb RunAs
  exit 0
}

New-Item -ItemType Directory -Force -Path $ProbeRoot | Out-Null

switch ($Command) {
  "install" {
    Install-VirtualBox
  }
  "adapters" {
    $items = @(Get-PhysicalAdapters)
    if (-not $items.Count) {
      Write-Host "No connected physical adapters found." -ForegroundColor Yellow
    } else {
      Write-Host "Windows physical adapters:" -ForegroundColor Cyan
      $items | Select-Object Name, InterfaceDescription, Status, LinkSpeed, MacAddress | Format-Table -AutoSize
    }
    try {
      $bridges = @(Get-VBoxBridgeInterfaces)
      if ($bridges.Count) {
        Write-Host "VirtualBox bridged interfaces:" -ForegroundColor Cyan
        $bridges | Select-Object Name, Status, IPAddress, HardwareAddress, Wireless | Format-Table -AutoSize
      }
    } catch {
      Write-Host "VirtualBox bridged interfaces unavailable: $($_.Exception.Message)" -ForegroundColor Yellow
    }
  }
  "up" {
    try {
      Ensure-ProbeVm
      Invoke-VBox -VBoxArgs @("startvm", "--type", "headless", $VmName) | Out-Null
      Write-Host "Started VirtualBox bridged LAN probe VM. Waiting for DHCP visibility..." -ForegroundColor Green
      Start-Sleep -Seconds 12
      Show-Status
    } catch {
      Write-StatusJson ([ordered]@{
        tool = "tyrnex-ai-rogue-lan-vbox-probe"
        mode = "virtualbox-bridged"
        vm_name = $VmName
        vm_exists = $false
        state = "start-failed"
        bridge_adapter = ""
        mac = ""
        ip_addresses = @()
        lan_visible_expected = $false
        status_path = $StatusPath
        note = $_.Exception.Message
      })
      Write-Host "VirtualBox bridged probe failed to start:" -ForegroundColor Red
      Write-Host $_.Exception.Message -ForegroundColor Yellow
      exit 1
    }
  }
  "status" {
    Show-Status
  }
  "down" {
    if (Get-VBoxVmExists) {
      Invoke-VBox -VBoxArgs @("controlvm", $VmName, "poweroff") | Out-Null
      Write-Host "Stopped VirtualBox probe VM." -ForegroundColor Green
    } else {
      Write-Host "VirtualBox probe VM is not present." -ForegroundColor Yellow
    }
    Show-Status
  }
  "remove" {
    if (Get-VBoxVmExists) {
      try { Invoke-VBox -VBoxArgs @("controlvm", $VmName, "poweroff") | Out-Null } catch {}
      Invoke-VBox -VBoxArgs @("unregistervm", $VmName, "--delete") | Out-Null
      Write-Host "Removed VirtualBox probe VM." -ForegroundColor Green
    } else {
      Write-Host "VirtualBox probe VM is not present." -ForegroundColor Yellow
    }
  }
}
