param(
  [string]$ControllerUrl = "",
  [string]$Label = "",
  [string]$AgentDir = "",
  [string]$StateDir = "",
  [switch]$StartAgent,
  [switch]$ForceReenroll
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path

function Resolve-TyrnexPython {
  $candidates = @(
    (Join-Path $root ".venv\Scripts\python.exe"),
    (Join-Path $root ".runtime\python\python.exe")
  )
  foreach ($candidate in $candidates) {
    if (Test-Path -LiteralPath $candidate) { return $candidate }
  }
  $fromPath = Get-Command python -ErrorAction SilentlyContinue
  if ($fromPath) { return $fromPath.Source }
  throw "Python was not found. Run 'Run This First.cmd' before enrolling a local agent."
}

function Read-ControllerUrl {
  $controllerJson = Join-Path $root "data\remote-controller\controller.json"
  if (Test-Path -LiteralPath $controllerJson) {
    $cfg = Get-Content -LiteralPath $controllerJson -Raw | ConvertFrom-Json
    if ($cfg.host -and $cfg.port) {
      return "https://$($cfg.host):$($cfg.port)"
    }
  }
  return ""
}

function ConvertTo-PlainText([securestring]$secure) {
  $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try {
    return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
  } finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
  }
}

Write-Host "TYRNEX-AI Local Agent Enrollment"
Write-Host "Creates or finishes enrollment for this Windows user/machine."
Write-Host "This does not disable AV/EDR, add firewall rules, install a service, or create hidden persistence."
Write-Host ""

if (-not $Label) { $Label = $env:COMPUTERNAME }
if (-not $AgentDir) {
  $runtimeDir = Join-Path $root "agent-runtime"
  $kitDir = Join-Path $root "agent"
  if (Test-Path -LiteralPath (Join-Path $runtimeDir "tyrnex-agent.exe")) {
    $AgentDir = $runtimeDir
  } elseif (Test-Path -LiteralPath (Join-Path $kitDir "tyrnex-agent.exe")) {
    $AgentDir = $kitDir
  } else {
    $AgentDir = $runtimeDir
  }
}
$AgentDir = (Resolve-Path -LiteralPath $AgentDir -ErrorAction Stop).Path
$agentExe = Join-Path $AgentDir "tyrnex-agent.exe"
if (-not (Test-Path -LiteralPath $agentExe)) {
  throw "Agent binary was not found at $agentExe. Build or copy agent\tyrnex-agent.exe first."
}

if (-not $StateDir) { $StateDir = Join-Path $AgentDir "agent-state" }
$StateDir = [IO.Path]::GetFullPath($StateDir)

if (-not $ControllerUrl) { $ControllerUrl = Read-ControllerUrl }
if (-not $ControllerUrl) {
  $ControllerUrl = Read-Host "Controller HTTPS URL, for example https://127.0.0.1:9443 or https://10.10.1.44:9443"
}
$ControllerUrl = $ControllerUrl.Trim().TrimEnd("/")
if ($ControllerUrl -notmatch '^https://[^/]+:\d+$') {
  throw "Use a controller URL like https://10.10.1.44:9443 with no path."
}

$identity = Join-Path $StateDir "identity.dpapi"
$request = Join-Path $StateDir "request.pem"
$device = Join-Path $StateDir "device.pem"
$ca = Join-Path $StateDir "ca.pem"
$agentConfig = Join-Path $StateDir "agent.json"

if ($ForceReenroll -and (Test-Path -LiteralPath $StateDir)) {
  $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
  $archive = "$StateDir.retired-$stamp"
  Move-Item -LiteralPath $StateDir -Destination $archive
  Write-Host "Existing agent state moved to $archive"
}

if ((Test-Path -LiteralPath $device) -and (Test-Path -LiteralPath $ca) -and (Test-Path -LiteralPath $agentConfig)) {
  Write-Host ""
  Write-Host "Agent is already enrolled."
  Write-Host "Agent: $agentExe"
  Write-Host "State: $StateDir"
  Write-Host "Controller: $ControllerUrl"
  if ($StartAgent) { & $agentExe --state $StateDir }
  exit 0
}

if (-not (Test-Path -LiteralPath $identity)) {
  Write-Host "Creating local agent identity and CSR..."
  & $agentExe --state $StateDir --init $ControllerUrl
  if ($LASTEXITCODE -ne 0) { throw "Agent identity creation failed." }
} else {
  Write-Host "Existing local identity found; reusing $StateDir"
}

if (-not (Test-Path -LiteralPath $request)) {
  throw "CSR was not found at $request"
}

$controllerJson = Join-Path $root "data\remote-controller\controller.json"
if (-not (Test-Path -LiteralPath $controllerJson)) {
  Write-Host ""
  Write-Host "Agent install prepared. Enrollment approval is still required on the TYRNEX controller."
  Write-Host "Copy this request file to the controller PC:"
  Write-Host "  $request"
  Write-Host "Approve it from the controller, then copy device.pem and ca.pem back to:"
  Write-Host "  $StateDir"
  Write-Host ""
  Write-Host "After those two files are present, rerun Install Remote Agent.cmd to start the agent."
  exit 0
}

$python = Resolve-TyrnexPython
$approvedRoot = Join-Path $StateDir "approved"
New-Item -ItemType Directory -Path $approvedRoot -Force | Out-Null
$out = Join-Path $approvedRoot (Get-Date -Format "yyyyMMdd-HHmmss")

Write-Host ""
Write-Host "Approving CSR against the local TYRNEX controller."
$controllerUnlock = Join-Path $root "data\remote-controller\controller-unlock.key"
$plain = $null
if (-not (Test-Path -LiteralPath $controllerUnlock)) {
  Write-Host "This controller uses the legacy manual key flow."
  $secure = Read-Host "Controller key passphrase" -AsSecureString
  $plain = ConvertTo-PlainText $secure
}
$oldEnv = $env:TYRNEX_CONTROLLER_PASSPHRASE
try {
  if ($plain) { $env:TYRNEX_CONTROLLER_PASSPHRASE = $plain }
  & $python -m tyrnex_ai.remote enroll --csr $request --label $Label --out $out
  if ($LASTEXITCODE -ne 0) { throw "Controller enrollment approval failed." }
} finally {
  if ($null -eq $oldEnv) {
    Remove-Item Env:\TYRNEX_CONTROLLER_PASSPHRASE -ErrorAction SilentlyContinue
  } else {
    $env:TYRNEX_CONTROLLER_PASSPHRASE = $oldEnv
  }
}

Copy-Item -LiteralPath (Join-Path $out "device.pem") -Destination $device -Force
Copy-Item -LiteralPath (Join-Path $out "ca.pem") -Destination $ca -Force

Write-Host ""
Write-Host "Local agent enrollment complete."
Write-Host "Agent: $agentExe"
Write-Host "State: $StateDir"
Write-Host "Controller: $ControllerUrl"
Write-Host ""
Write-Host "Start the visible foreground agent with:"
Write-Host "  `"$agentExe`" --state `"$StateDir`""
Write-Host ""
Write-Host "Open TYRNEX-AI > Remote devices, unlock with the operator token, and run Host inventory."

if ($StartAgent) {
  Write-Host ""
  Write-Host "Starting foreground agent. Ctrl+C stops it."
  & $agentExe --state $StateDir
}
