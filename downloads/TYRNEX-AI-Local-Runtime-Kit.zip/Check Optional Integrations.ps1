$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$python = Join-Path $root ".venv\Scripts\python.exe"
function Test-PythonRuntime {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) { return $false }
  try {
    & $Path -c "import sys; print(sys.executable)" *> $null
    return $LASTEXITCODE -eq 0
  } catch {
    return $false
  }
}
if (-not (Test-PythonRuntime $python)) {
  Write-Host "Runtime is missing, broken, or was moved from another machine. Running first-run setup..." -ForegroundColor Yellow
  & (Join-Path $root "Run This First.ps1") -NoStart -SkipToolBootstrap
  if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
if (-not (Test-PythonRuntime $python)) {
  Write-Host "Runtime is not installed yet. Run 'Run This First.cmd' after installing Python 3.11+." -ForegroundColor Red
  exit 1
}
$env:PYTHONPATH = "$root;$env:PYTHONPATH"
Push-Location $root
& $python -m tyrnex_ai.cli doctor
Pop-Location
