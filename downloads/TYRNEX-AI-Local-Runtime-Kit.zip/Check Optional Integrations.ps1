$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path -LiteralPath $python)) {
  Write-Host "Runtime is not installed yet. Run 'Run This First.cmd' first." -ForegroundColor Red
  exit 1
}
$env:PYTHONPATH = "$root;$env:PYTHONPATH"
Push-Location $root
& $python -m tyrnex_ai.cli doctor
Pop-Location
